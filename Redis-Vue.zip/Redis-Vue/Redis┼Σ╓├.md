# Redis配置

Redis的配置信息在`/etc/redis/redis.conf`下

#### 查看

```
sudo vi /etc/redis/redis.conf
```

端口默认

```
port 6379
```

数据文件存储路径

```
dir /var/lib/redis
```

日志文件

```
logfile "/var/log/redis/redis-server.log"
```

数据库，默认16个

```
database 16
```

主从复制，类似于双机备份

```
slaveof
```

#### 配置

```
配置文件位置：/etc/redis/redis.conf
编辑配置文件：sudo vim /etc/redis/redis.conf
建议修改项：
	注释掉bind：# bind 127.0.0.1
	关闭保护模式：protectd-mode no
	后台运行：daemonize yes
重启redis：
	查看进程pid：ps aux | grep redis-server
	杀掉进程：sudo kill -9 pid
	启动redis：sudo redis-server /etc/redis/redis.conf
	
管理
	必须先开启服务端：
		先查看服务端是否开启：ps aux | grep redis-server
		如果服务端已开启就不管
		如果没有开启就开启：sudo redis-server /etc/redis/redis.conf
	然后再使用redis-cli登录到redis-server
		使用默认的IP和端口访问：
			redis-cli
		使用真实IP访问：
			redis-cli -h ubuntu真实IP
测试
	ping
```

