# 数据操作

#### 键命令

- 查找键

  ```
  keys pattern
  例：
  keys *
  查看包含a的键
  keys a*
  ```

- 判断是否存在，存在返回1  否则0

  ```
  exists key
  ```

- 查看键对应命令

  ```
  type key
  ```

- 删除键

  ```
  del key
  ```

- 设置过期时间

  ```
  expire key seconds
  例：
  expire name 5
  ```

- 查看有效时间

  ```
  ttl key
  ```



#### **string类型**

- 设置键值

  ```
  set key value
  例：
  set name itcast
  设置多个键值
  mset key value key value
  ```

- 获取键值

  ```
  get key
  例：
  get name
  获取多个键值
  mget key1 key2 key3
  ```

- 设置键值及过期时间，以秒为单位

  ```
  setex key seconds value
  例：
  setex name 5 abc
  ```

#### hash类型

​	键-->属性-->值

- 设置

  ```
  hset key field value
  例：设置键 user 的属性 name 为 lh
  hset user name lh
  设置多个属性
  hset key field1 value1 field2 value2
  ```

- 获取指定键的所有属性

  ```
  hkeys key
  ```

- 获取某个属性的值

  ```
  hget key field
  获取多个属性的值
  hmget key field1 field2
  ```

- 删除

  ```
  删除键
  del key
  删除属性
  hdel key field1 field2
  ```

#### list类型

按照插入顺序排序

- 从左侧插入数据

  ```
  lpush key value1 value2
  ```

- 从右侧插入数据

  ```
  rpush key value1 value2
  ```

- 指定元素前或后插入新元素

  ```
  linsert key before或after 现有元素 新元素
  例：在 a 元素前插 1
  linsert test before a 1
  ```

- 获取

  ```
  lrange key start stop
  例：获取test键的所以元素
  lrange test 0 -1
  ```

- 删除

  - 将列表中前`count`次出现的值为`value`的元素移除
  - count > 0: 从头往尾移除
  - count < 0: 从尾往头移除
  - count = 0: 移除所有

  ```
  lrem key count value
  例：从右侧开始删除2个b
  lrem test -2 b
  从左侧开始删除2个a
  lrem test 2 a
  ```

#### set类型

- 无序集合
- 唯一性，不重复

- 添加

  ```
  sadd key member1 member2
  例：
  sadd test zhangsan lisi wangwu
  ```

- 获取所有元素

  ````
  smembers key
  例：
  smembers test
  ````

- 删除

  ```
  srem key
  例：
  srem test wangwu
  ```

#### zset类型

- sorted set 有序集合

- 唯一性，不重复

- 每个元素都关联一个double类型的score，表示权重

- 通过权重排序

- 添加

  ```
  zadd key score member1 score member2
  例：添加test键 权重为20的值 和 权重为10的值 和 权重为30的值
  zadd test 20 lisi 10 zhangsan 30 wangwu
  ```

- 获取

  ```
  zrange key start stop
  例：获取test键中所有元素
  zrange test 0 -1
  
  根据权重获取之间元素
  zrangebyscore key min max
  zrangebyscore test 10 30
  
  返回成员的权重
  zscore key member
  zscore test zhangsan
  ```

- 删除

  ```
  删除指定元素
  zrem key member1 member2
  例：
  zrem rest lisi zhangsan
  
  删除权重范围内的
  zremrangebyscore key min max
  ```

  