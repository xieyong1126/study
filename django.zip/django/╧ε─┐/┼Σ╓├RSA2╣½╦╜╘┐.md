 

``` 
1. 创建文件夹      mkdir keys
2. 进入目录        cd keys
3. 进入openssl环境 openssl
4.生成私钥  genrsa -out app_private_key.pem 2048 
5.生成公钥  rsa -in app_private_key.pem -pubout -out app_public_key.pem
6.退出     exit

公私钥格式

-----BEGIN PUBLIC KEY-----
将支付宝公钥内容, 拷贝到此处
-----END PUBLIC KEY-----

```

``` 
添加支付宝支付功能时，需要和支付宝互换公钥，
在keys目录中添加将支付宝公钥内容拷贝到 alipay_public_key.pem 文件中
```

