## Django用户认证底层原理

### 1. 背景说明

>1. Django默认自带用户认证系统，用于用户的创建、认证、权限管理等操作。
>2. 我们这里讨论的是Django默认的用户认证的底层原理。
>3. Django默认的用户认证子应用：**`django.contrib.auth`**。

### 2. 概念

> 用户认证核心内容
>
> * 用户登录时：
>    * 验证用户，即使用账号和密码作为凭据验证该用户是否是网站的注册用户。
>     * 状态保持，即用户通过验证后，存储用户唯一信息作为用户已登录的凭据。
>* 每次访问时：
>     * 认证中间件，即用户每次请求到服务端都会从状态保持信息中认证出该用户是谁。

### 3. 验证用户

> * 验证用户方法：**`django.contrib.auth.authenticate`**
>     * 用户登录时要去调用的方法，传入验证用户的凭据 （账号和密码），内部会去调用《验证用户后端》去验证该用户。
> * 验证用户后端：**`django.contrib.auth.backends.ModelBackend`**
>     * 验证用户时最底层的类，实现用户的验证，返回通过验证的用户对象。

```python
# 验证用户方法
def authenticate(request=None, **credentials):
    """
    If the given credentials are valid, return a User object.
    如果给定的凭据有效, 则返回用户对象.
    参数说明：
    	**credentials：凭据，必传凭据为账号和密码
    """
    # 会去调用《验证用户的后端》
    pass
```

```python
# 验证用户后端
class ModelBackend(object):
    """
    Authenticates against settings.AUTH_USER_MODEL.
    根据settings.AUTH_USER_MODEL进行身份验证，即根据《用户模型类》进行身份验证.
    """
    def authenticate(self, request, username=None, password=None, **kwargs):
        """
    	对用户进行身份验证的底层方法
        :param username: 用户名(默认的)
        :param password: 密码
        :param kwargs: 其他额外凭据
        :return: user
        """
        if username is None:
            username = kwargs.get(UserModel.USERNAME_FIELD)
        try:
            # 使用用户名(默认的)作为条件查询用户表中用户是否存在
            # user = User.objects.get(username=username)
            user = UserModel._default_manager.get_by_natural_key(username)
        except UserModel.DoesNotExist:
            # ......
        else:
            # 如果用户存在，再去校验密码是否输入正确
            if user.check_password(password) and self.user_can_authenticate(user):
                # 如果用户存在，且密码正确，就返回通过验证的用户对象
                return user
```

### 4. 状态保持

> 提示：
>
> * Django默认采用Session机制实现状态保持

> 状态保持效果：
>
> * session的key：一个随机且唯一字符串
>     * 用户通过验证后，`session的key`会写入到用户浏览器的`cookie`中。
>
> * session的value：通过验证的用户的ID + 验证的后端信息 + 用户密码HMAC加密后的结果
>     * 用户通过验证后，`session的value`会存储到`session后端`。比如：`Redis`

> 状态保持底层：
>
> * 如何生成`session的key和value`？
>     * **login()方法：`django.contrib.auth import login`**
> * 如何存储`session的key和value`？
>     * **Session中间件：`django.contrib.sessions.middleware.SessionMiddleware`**

```python
def login(request, user, backend=None):
    """
    状态保持：使用已通过验证的用户信息生成session数据的值
    :param user: 已通过验证的用户
    :param backend: 验证后端
    """
    # 此处省略状态保持的前期准备工作......
    
    # 以下代码为生成session的key
    request.session.cycle_key()
    
    # 以下代码为生成session的value
    # 用户ID
    request.session[SESSION_KEY] = user._meta.pk.value_to_string(user)
    # 用户验证后端
    request.session[BACKEND_SESSION_KEY] = backend
    # 用户密码HMAC加密后的结果
    request.session[HASH_SESSION_KEY] = session_auth_hash
```

```python
class SessionMiddleware(MiddlewareMixin):
    """Session中间件"""
    def process_response(self, request, response):
        """处理响应"""
        # 以下为摘取的核心代码
        # 将session的value存储到session后端：比如，Redis
        request.session.save()
        
        # 将session的key写入到用户浏览器的cookie
        response.set_cookie(
            settings.SESSION_COOKIE_NAME,
            request.session.session_key, max_age=max_age,
            expires=expires, domain=settings.SESSION_COOKIE_DOMAIN,
            path=settings.SESSION_COOKIE_PATH,
            secure=settings.SESSION_COOKIE_SECURE or None,
            httponly=settings.SESSION_COOKIE_HTTPONLY or None,
        )
```

### 5. 认证中间件

> Session中间件：
>
> * **`django.contrib.sessions.middleware.SessionMiddleware`**
> * 作用：
> 	 	* 从cookie中读取session的key，将来用于读取session数据。
>
> 认证中间件：(依赖于Session中间件)
> * **`django.contrib.auth.middleware.AuthenticationMiddleware`**
>
> * 作用：
> 	* 使用`session_key`从session数据中读取出用户ID，并使用用户ID查询出对应的用户对象或者匿名用户对象。
> 	
> 	* 最终将认证出来的用户对象赋值给 `request.user` 属性
> 	
>
> 中间件执行顺序	
>
> * **`django.contrib.sessions.middleware.SessionMiddleware`**
> * **`django.contrib.auth.middleware.AuthenticationMiddleware`**

```python
class SessionMiddleware(MiddlewareMixin):
    """Session中间件"""
    def process_request(self, request):
        """处理请求"""
        # 从cookie中读取session的key
        session_key = request.COOKIES.get(settings.SESSION_COOKIE_NAME)
        request.session = self.SessionStore(session_key)
        pass
```

```python
def get_user(request):
    """
    Returns the user model instance associated with the given request session.
    If no user is retrieved an instance of `AnonymousUser` is returned.
    返回与给定请求会话关联的用户模型实例.
	如果没有检索到用户，则返回' AnonymousUser '的实例.
    """
    from .models import AnonymousUser
    user = None
    try:
        # 使用session的key从session数据中读取用户ID
        user_id = _get_user_session_key(request)
        backend_path = request.session[BACKEND_SESSION_KEY]
    except KeyError:
        pass
    else:
        if backend_path in settings.AUTHENTICATION_BACKENDS:
            backend = load_backend(backend_path)
            # 使用用户ID获取到对应的用户模型对象
            user = backend.get_user(user_id)
            # ......
            
	# 如果user有值，则返回user。反之，返回匿名用户对象
    return user or AnonymousUser()

class AuthenticationMiddleware(MiddlewareMixin):
    """认证中间件"""
    def process_request(self, request):
        """从session中读取用户信息，并赋值给request的user属性"""
        request.user = SimpleLazyObject(lambda: get_user(request))
```

### 6. 总结

```
用户认证核心内容：
	验证用户：使用凭据（账号和密码）验证该用户是否是注册用户。
	状态保持：如果该用户通过了验证，就将该用户的唯一信息缓存起来作为状态保持数据。
	认证中间件：用户每次请求到服务端都会从状态保持信息中认证出该用户是谁。
```

### 7. 反思

```
1. 如何判断用户是否登录？
	读取request.user的值
	如果值为具体的用户模型对象，则用户已登录。
	如果值为None或者AnonymousUser，则用户未登录。
```

### 8. 补充密码加密和解密

> 密码加密
* `set_password(raw_password)`
> 密码解密
* `check_password(raw_password)`

```
密码加密：set_password('123456789')
1. 确定加密算法、迭代次数、盐
	加密算法：pbkdf2_sha256
	迭代次数：36000
	盐：随机字符串(jSR4lZQK2d0g)
2. 使用加密算法加密密码明文
	b7ae0af0532335b035bca48cc134f0aabf128cebfdec9b8159f4e7ab8bc9ec60
3. 使用base64对密码密文进行编码
YjdhZTBhZjA1MzIzMzViMDM1YmNhNDhjYzEzNGYwYWFiZjEyOGNlYmZkZWM5YjgxNTlmNGU3YWI4YmM5ZWM2MA==
4. 拼接密码密文
pbkdf2_sha256$36000$jSR4lZQK2d0g$YjdhZTBhZjA1MzIzMzViMDM1YmNhNDhjYzEzNGYwYWFiZjEyOGNlYmZkZWM5YjgxNTlmNGU3YWI4YmM5ZWM2MA==

密码解密
使用之前注册时相同的加密标准去加密，如果得到了相同的结果，那么该密码明文就是正确的
```



