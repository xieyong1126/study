#### 事务隔离级别

``` 
MySQL数据库事务隔离级别主要有四种：隔离性  强————>弱

Serializable：串行化，一个事务一个事务的执行。
Repeatable read：可重复读，无论其他事务是否修改并提交了数据，在这个事务中看到的数据值始终不受其他事务影响。
Read committed：读取已提交，其他事务提交了对数据的修改后，本事务就能读取到修改后的数据值。
Read uncommitted：读取未提交，其他事务只要修改了数据，即使未提交，本事务也能看到修改后的数据值。
MySQL数据库默认使用可重复读（ Repeatable read）
```

#### 修改方式

``` 
cd /etc/mysql/mysql.conf.d/
#mysqld.cnf mysql_safe_syslog.cnf
sudo vim mysqld.cnf

插入
transaction-isolation=READ-COMMITTED
```

#### 乐观锁

``` 
原理：
乐观锁并不是真实存在的锁，而是在更新的时候判断此时的库存是否是之前查询出的库存，如果相同，表示没人修改，可以更新库存，否则表示别人抢过资源，不再执行库存更新。类似如下操作
	update tb_sku set stock=2 where id=1 and stock=7;

	SKU.objects.filter(id=1, stock=7).update(stock=2)
```



``` python
while True：   
    #  读取原始库存
    origin_stock = sku.stock
    origin_sales = sku.sales
    ....
    # 乐观锁更新库存和销量,计算差值
    new_stock = origin_stock - count
    new_sales = origin_sales + count

    result = SKU.objects.filter(id=sku_id,stock=origin_stock
      ).update(stock=new_stock, sales=new_sales)
    #成功result=1,失败reslut=0
    # 如果下单失败，但是库存足够时，
    # 继续下单，直到下单成功或者库存不足为止
     if result == 0:
         continue
    .....
	#成功后跳出
    break

```

