``` python
#子路由文件中, 可以通过 app_name 指定子应用所在的命名空间名称(可以理解为该子应用的名称).可以通过 name 属性指定子应用中某一条路径的名称.
from django.conf.urls import re_path
from . import views

app_name = 'user'

urlpatterns = [
    re_path(r'^index/$', views.index, name='index'),
    re_path(r'^say', views.say, name='say'),
]

```



#### 视图中使用

``` python
from django.urls import reverse  # 注意导包路径
from django.shortcuts import redirect

def index(request):
    '''index函数'''

    # 我们在index函数中获取say函数的路径
    url = reverse('user:say')
    print(url)     # /users/say
	#return  redirect('/users/say/')
	return redirect(url)


def say(request):
    '''say函数'''
    return HttpResponse('say')


```

