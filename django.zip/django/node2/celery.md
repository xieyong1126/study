`pip install Celery `

` 定义 Celery 包名,字叫做: celery_tasks`

` 在 celery_tasks 包中添加 main.py 文件:`

``` python
#main.py
# 从你刚刚下载的包中导入 Celery 类
from celery import Celery

# 利用导入的 Celery 创建对象
celery_app = Celery('XXX')

# 将刚刚的 config 配置给 celery
# 里面的参数为我们创建的 config 配置文件:
celery_app.config_from_object('celery_tasks.config')

# 让 celery_app 自动捕获目标地址下的任务: 
# 就是自动捕获 tasks
celery_app.autodiscover_tasks(['celery_tasks.sms'])
```

`在 celery_tasks 包中再添加一个 config.py 文件 `

``` python
#config.py
# 如果使用 redis 作为中间人
# 需要这样配置:
broker_url='redis://127.0.0.1:6379/3'

# 如果使用别的作为中间人, 例如使用 rabbitmq
# 则 rabbitmq 配置如下:
#broker_url= 'amqp://用户名:密码@ip地址:5672'

# 例如: 
# meihao: 在rabbitq中创建的用户名, 注意: 远端链接时不能使用guest账户.
# 123456: 在rabbitq中用户名对应的密码
# ip部分: 指的是当前rabbitq所在的电脑ip
# 5672: 是规定的端口号
#broker_url = 'amqp://meihao:123456@172.16.238.128:5672'
```

##### 注册任务：

我们需要在 celery_tasks 包下, 再创建一个包, 名字随意

例如, 我这里为 sms.

创建好后, 需要在里面添加一个 tasks.py 文件.

注意, 这里的 tasks 名字是规定死的.

然后需要在 celery_tasks.main.py 报备刚刚创建的文件:

 

`在 celery_tasks.sms.tasks.py 文件中添加如下代码: `

``` python
#tasks.py
from celery_tasks.main import celery_app

@celery_app.task(name='ccp_send_sms_code')
def ccp_send_sms_code(mobile, sms_code):
    '''该函数就是一个任务, 用于发送短信'''
    result = CCP().send_template_sms(mobile, 
                                     [sms_code, 5], 
                                     1)
    return result
```

##### 调用任务

``` python
from celery_tasks.sms.tasks import ccp_send_sms_code
# 改为现在的写法, 注意: 这里的函数,调用的时候需要加: .delay()
ccp_send_sms_code.delay(mobile, sms_code)
```

`启动celery`

``` shell
#终端中
# 想要启动 celery 服务, 调用下面的命令行: 
cd ~/projects/XXX_project/XXX

celery -A celery_tasks.main worker -l info
```

``` shell
#补充
#默认是进程池方式:
#进程数以当前机器的CPU核数为参考，每个CPU开四个进程
如何自己指定进程数：celery worker -A proj --concurrency=4
如何改变进程池方式为协程方式：celery worker -A proj --concurrency=1000 -P eventlet -c 1000

# 安装 eventlet 模块
$ pip install eventlet

# 启用 Eventlet 池
$ celery -A celery_tasks.main worker -l info -P eventlet -c 1000

```

