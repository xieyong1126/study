# 中间件Middleware

#### **1、中间件介绍**

- ​	当某些操作需要在每次请求或者响应时，可以写在中间件中

#### **2、中间件方法**

- Django在中间件中预置了六种方法，在不同的阶段自动执行，对输入或输出进行干预

  - 2.1 初始化方法：

    - 启动Django程序，初始化中间件时，自动调用一次，用于确定是否启用当前中间件

      ```python
      def __init__(self, get_response=None):
        pass
      ```

  - 2.2 处理请求前的方法：**(重要)**

    - 在处理每个请求前，自动调用，返回None或HttpResponse对象

      ```python
      def process_request(self, request):
        pass
      ```

  - 2.3 处理视图前的方法：**（重要）**

    - 在处理每个视图前，自动调用，返回None或HttpResponse对象

      ```python
      def process_view(self, request, view_func, view_args, view_kwargs):
        pass
      ```

  - 2.4 处理模板响应前的方法：

    - 在处理每个模板响应前，自动调用，返回实现了render方法的响应对象

      ```python
      def process_template_response(self, request, response):
        pass
      ```

  - 2.5 处理响应后的方法：**（重要）**

    - 在每个响应返回给客户端之前，自动调用，返回HttpResponse对象

      ```python
      def process_response(self, request, response):
        pass
      ```

  - 2.6 异常处理：

    - 当视图抛出异常时，自动调用，返回一个HttpResponse对象

      ```python
      def process_exception(self, request,exception):
        pass
      ```



#### 3、自定义中间件

- 在工程目录创建`middlewares.py`文件

- 导入中间件的父类

  1. ```python
     from django.utils.deprecation import MiddlewareMixin
     ```

- 自定义中间件

  ```python
  class TestMiddleware1(MiddlewareMixin):
      """自定义中间件"""
      def process_request(self, request):
          """处理请求前自动调用"""
          print('process_request1 被调用')
  
      def process_view(self, request, view_func, view_args, view_kwargs):
          # 处理视图前自动调用
          print('process_view1 被调用')
  
      def process_response(self, request, response):
          """在每个响应返回给客户端之前自动调用"""
          print('process_response1 被调用')
          return response
  ```

- 注册自定义中间件

  在`settings.py`

  ```
  # 中间件
  MIDDLEWARE = [
      'django.middleware.security.SecurityMiddleware',
      'django.contrib.sessions.middleware.SessionMiddleware',
      'django.middleware.common.CommonMiddleware',
      # 为保证非GET请求(POST, PUT, DELETE)可以正常接收，该中间件需要注释掉
      # 'django.middleware.csrf.CsrfViewMiddleware',
      'django.contrib.auth.middleware.AuthenticationMiddleware',
      'django.contrib.messages.middleware.MessageMiddleware',
      'django.middleware.clickjacking.XFrameOptionsMiddleware',
      
      # 注册自定义的中间件1
      # 文件名.类名
      'middlewares.TestMiddleware1', 
  ]
  ```

4、中间件执行顺序

- ​	请求返回 和 请求视图 是自上而下执行
- ​    请求响应 是自下而上执行

> **重要提示：中间件执行顺序**

- 在视图被处理前(输入)，中间件**由上至下**依次执行
- 在视图被处理后(输出)，中间件**由下至上**依次执行



**中间件定义(本质就是⼀一个装饰器器)** 

``` python
def my_middleware(get_response):
	print('init 被调⽤用')
	def middleware(request):
		print('before request 被调⽤用')
		response = get_response(request)
		print('after response 被调⽤用')
		return response
	return middleware
```

``` python
# 在django的配置⽂文件中
MIDDLEWARE = [
	# 此处添加的是⾃自定义中间件的导包路路径(根据⾃自⼰己实际定义的位置写)
	'utils.middleware.my_middleware',
]
```

