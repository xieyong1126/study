**下载**

``` bash
yum -y install docker
systemctl start docker.service
systemctl enable docker.service
```

**docker-compose**

``` 
官网安装步骤地址：https://docs.docker.com/compose/install/#install-compose
1、安装curl -L https://github.com/docker/compose/releases/download/1.21.2/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
 
2、赋权Apply executable permissions to the binary:
sudo chmod +x /usr/local/bin/docker-compose
 
3、ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
 
4、查看版本
docker-compose --version
```

**加速**

``` 
# cat /etc/docker/daemon.json     
{"registry-mirrors": ["https://d8b3zdiw.mirror.aliyuncs.com"],
"insecure-registries": ["https://ower.site.com"]
}
```

**更新**

``` bash
#Docker 要求 CentOS 系统的内核版本高于 3.10 ,查看CentOS的内核版本。
uname -a

#查看
rpm -qa | grep docker

#删除旧版本
yum remove docker  docker-common docker-selinux docker-engine

#安装需要的软件包
#yum-util 提供yum-config-manager功能，另外两个是devicemapper驱动依赖的
yum install -y yum-utils device-mapper-persistent-data lvm2

#设置Docker yum源
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

#查看所有仓库中所有docker版本
yum list docker-ce --showduplicates | sort -r

#安装docker
yum install docker-ce

#如果要安装特定版本
yum install docker-ce-18.06.1.ce

#设置为开机启动
systemctl enable docker

systemctl start docker
systemctl status docker
docker version
```

