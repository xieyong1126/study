### 使用 Docker 安装 Elasticsearch

```bash
# 从仓库拉取镜像
sudo docker image pull delron/elasticsearch-ik:2.4.6-1.0
```

```bash
# 或者是: 解压本地镜像
sudo docker load -i elasticsearch-ik-2.4.6_docker.tar
将资料中的elasticsearc-2.4.6目录拷贝到home目录下。
修改/home/elasticsearc-2.4.6/config/elasticsearch.yml第54行。
更改 ip 地址为本机真实 ip 地址。
(network.host:192.168.208.129)
```

**使用 Docker 运行 Elasticsearch-ik**

` sudo docker run -dti --name=elasticsearch --network=host -v /home/elasticsearch-2.4.6/config:/usr/elasticsearch/config delron/elasticsearch-ik:2.4.6-1.0`

### Haystack 介绍和安装配置

```bash
联网安装haystack和elasticsearch
pip install django-haystack
pip install elasticsearch==2.4.1
```

**Haystack 注册应用**

```python
INSTALLED_APPS = [
     # 全文检索
    'haystack', 
]
```

**Haystack 配置**

在配置文件中配置 Haystack 为搜索引擎后端

```python
# Haystack
HAYSTACK_CONNECTIONS = {
    'default': {
        'ENGINE': 'haystack.backends.elasticsearch_backend.ElasticsearchSearchEngine',
        'URL': 'http://192.168.208.129:9200/', # Elasticsearch服务器ip地址，端口号固定为9200
        'INDEX_NAME': 'jingdong', # Elasticsearch建立的索引库的名称
        #保存索引文件的路径
        #'PATH': os.path.join(BASE_DIR, 'elastic_index'),
    },
}

# 当添加、修改、删除数据时，自动生成索引
HAYSTACK_SIGNAL_PROCESSOR = 'haystack.signals.RealtimeSignalProcessor'
#HAYSTACK_SIGNAL_PROCESSOR 配置项保证了在 Django 运行起来后，有新的数据产生时，Haystack 仍然可以让 Elasticsearch 实时生成新数据的索引
# # 指定搜索结果每页的条数 这里设置成了1条
# HAYSTACK_SEARCH_RESULTS_PER_PAGE = 1
```

 **Haystack 建立数据索引**

- 通过创建索引类，来指明让搜索引擎对哪些字段建立索引，也就是可以通过哪些字段的关键字来检索数据。
- 本项目中对 SKU 信息进行全文检索，所以在 `goods` 应用中新建 `search_indexes.py` 文件，用于存放索引类。

```python
from haystack import indexes
from .models import Article
class ArticleIndex(indexes.SearchIndex, indexes.Indexable):
    """Article索引数据模型类"""
    #ArticleIndex=模型类名+Index
    text = indexes.CharField(document=True, use_template=True)
     # 一般此字段约定为text
    #http://127.0.0.1:8000/articles/search/?text=来
#    @staticmethod
#    def prepare_autocomplete(obj):
#        return " ".join((
#            obj.createtime, obj.content, obj.title,obj.id
#        ))
#（未知）
    def get_model(self):
        """返回建立索引的模型类"""
        return SKU
    def index_queryset(self, using=None):
        """返回要建立索引的数据查询集"""
        return self.get_model().objects.filter(过滤条件，如id__gt=2)
#其中 text 字段我们声明为 document=True，表名该字段是主要进行关键字查询的字段。
#text字段的索引值可以由多个数据库模型类字段组成，具体由哪些模型类字段组成，我们用 use_template=True 表示后续通过模板来指明。
#在 REST framework中，索引类的字段会作为查询结果返回数据的来源
```

**.创建 text 字段索引值模板文件**（不用）

` 在 `templates` 目录中创建 `text 字段`使用的模板文件,具体在 templates/search/indexes/headline/article_text.txt 文件中定义（headline=应用名，article_text=模型类小写名_text）`

`templates是项目原来的html文件的目录,search是在其下新建的,名称一定,indexes名称也一定,demo是应用的名称,demo_text.txt 就是需要进行索引的模型类名的小写 + "_" + 索引类中定义的字段名称(text) + ".txt`

```python
{{ object.id }}
{{ object.createtime }}
{{ object.content }}
{{ object.title }}
#id,name,caption作为text字段的索引值，（是模型中的字段）
```

**手动生成初始索引**

` python manage.py rebuild_index`

### 全文检索测试

> **1.准备测试表单**

- 请求方法：`GET`
- 请求地址：`/search/`
- 请求参数：`q`

**模型类**

``` python
class Article(models.Model):
    title = models.CharField(max_length=100, null=True, default=None, verbose_name="标题")
    content = RichTextUploadingField(default='', verbose_name='文章内容')
    createtime = models.DateTimeField(auto_now_add=True, null=True, verbose_name="创建日期")

    class Meta:
        db_table = "tb_article"
        verbose_name = "文章"
        verbose_name_plural = verbose_name
        ordering = ['-createtime']
    def __str__(self):
        return self.title
```



**序列化器**

``` python
#搜索文章列表
class ArticleListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Article
        #需要返回的字段
        fields = ['id','createtime','content','title']


from drf_haystack.serializers import HaystackSerializer
from .search_indexes import ArticleIndex
class DemoSerializer(HaystackSerializer):
     # 变量名称必须为 object 否则无法返回
    object = ArticleListSerializer(read_only=True)

    class Meta:
        index_classes = [ArticleIndex,]#索引类的名称
        fields = ('text', 'object',)  # text 由索引类进行返回, object 由序列化类进行返回,第一个参数必须是text
```

**实图**

``` python
#Es搜索
from drf_haystack.viewsets import HaystackViewSet

from django.core.paginator import Page
from .serializers import DemoSerializer
class SeachEsView(HaystackViewSet):
    '''重写SearchView类'''
    index_models = [Article,]#这里可以写入多个已经进行了索引的模型类
    serializer_class = DemoSerializer
    #pagination_class = MyPage
```

**路由**

``` python
 url(r'^articles/search/$',views.SeachEsView.as_view({
        'get':'list'
    })),
```

**分页器**

``` python
class MyPage(PageNumberPagination):
    page_query_param = "page"
    page_size_query_param = 'pagesize'
    page_size = 5 # 后端默认使用的每页数量
    max_page_size = 10 # 最大的每页数据
    # 构造数据返回
    def get_paginated_response(self, data):
        # 参数data：当前页数据序列化的结果
        # 构造符合我们接口定义的分页返回的格式
        return Response({
            'count': self.page.paginator.count,
            'results': data,
            'next':self.get_next_link(),#上一页
            'previous':self.get_previous_link(),#下一页
        })
    

```

**返回结果**

```  python
#不加分页器
[
    {
        "text": "4\n再来一次\n&lt;p&gt;炽&lt;/p&gt;",
        "object": {
            "id": 4,
            "createtime": "2020-07-25T20:07:32.706140+08:00",
            "content": "<p>炽</p>",
            "title": "再来一次"
        }
    }
]

#加分页器
{
    "count": 1,
    "results": [
        {
            "text": "4\n再来一次\n&lt;p&gt;炽&lt;/p&gt;",
            "object": {
                "id": 4,
                "createtime": "2020-07-25T20:07:32.706140+08:00",
                "content": "<p>炽</p>",
                "title": "再来一次"
            }
        }
    ],
    "next": null,
    "previous": null
}
```

