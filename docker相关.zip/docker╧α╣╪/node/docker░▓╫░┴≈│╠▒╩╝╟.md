ps：所有涉及到的文件到`FastDFS安装和镜像.tar.gz`解压包里去找！！

##### —————————————前提准备———————————————

##### 0、安装docker工具

- 1、把`docker本地安装`文件夹拷贝到ubuntu虚拟机中
- 2、进入文件夹`cd docker本地安装`
- 3、执行安装指令
  - `sudo apt-key add gpg`
  - `sudo dpkg -i docker-ce_17.03.2~ce-0~ubuntu-xenial_amd64.deb`

##### 1、下发一个镜像压缩包

把`fastdfs_docker.tar`文件拷贝到你的ubuntu中！

##### 2、把压缩包恢复到你的ubuntu本地镜像中

`sudo docker image load -i fastdfs_docker.tar`



##### ——————————安装tracker和storage容器—————————

##### 3、把`delron/fastdfs:latest`运行成容器(搭建了fastdfs分布式文件存储服务)

3.0 在ubuntu宿主机中创建两个文件夹，用来保存容器产生的数据的！

如果宿主机文件夹**不存在，先创建**！！   运行镜像时会自动创建

- `/var/fdfs/tracker/`: 保存tracker容器数据
- `/var/fdfs/storage/`: 保存storage容器数据

3.1 根据镜像运行tracker服务器

`sudo docker container run -itd  --name tracker  --network=host  -v /var/fdfs/tracker/:/var/fdfs/ delron/fastdfs:latest tracker`

参数解释：

- `--name`: 容器别名
- `--network=host`: 使用容器宿主机ip和端口访问容器
- `-v <宿主机目录>:<容器目录>`: 把容器目录映射到宿主机指定目录（容器该目录下保存到文件相当于保存到了宿主机指定目录下）
- `tracker`：镜像作者提供的一个指令，用来把该镜像运行成一个tracker服务

3.2 根据镜像运行storage服务器

`sudo docker container run -itd --name storage --network=host -v /var/fdfs/storage/:/var/fdfs/  -e TRACKER_SERVER=192.168.203.156:22122  delron/fastdfs:latest storage`

参数解释：

- `-e`: 定义启动容器传入的环境变量，此处环境变量`TRACKER_SERVER`为镜像作者定义，用来获取tracker服务的ip和端口的；
- `storage`: 镜像作者提供的一个指令，用来把该镜像运行成一个storage服务

##### 4、恢复storage存储数据

- 1、把`data.tar.gz`拷贝到你的ubuntu里
- 2、把该压缩包解压到`/var/fdfs/storage/`目录下，覆盖原有目录下的data文件夹
  - `tar -zxvf data.tar.gz -C /var/fdfs/storage/`

