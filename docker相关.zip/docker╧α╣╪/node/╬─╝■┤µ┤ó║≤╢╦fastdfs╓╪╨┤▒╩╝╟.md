##### 1、根据`FastDFS客户端安装`中指定的客户端版本安装fdfs客户端程序

`pip3 install fdfs-client-py==1.2.6`

`pip3 install mutagen==1.41.0`

`pip3 install requests==2.19.1`



##### 2、文件存储后端逻辑

- 文件类型字段，前端传递的图片数据，经过序列化器校验之后，有效数据是一个**文件对象**

  ```python
  # 前端传递数据，image字段是一个文件数据
  {"image": <binary>}
  
  # 后端序列化器校验,后的有效数据
  {"image": <InMermoryUploadFile>} # InMermoryUploadFile表示一个文件对象
  ```

- 模型类对象在新建的时候，如果文件类型字段传入一个文件对象，会调用存储后端实现文件保存

  ```mermaid
  graph TD;
  	a[图片数据] --前端传递--> b[django后端]
  	b --校验--> c[有效数据为一个文件对象]
  	c --模型类新建--> d[新建模型类对象的时候image字段被赋值为一个文件对象]
  	d --调用存储后端--> e[存储后端save方法完成保存文件逻辑]
  ```
  
- 把`client.conf`文件拷贝到`meiduo_mis_sz37/meiduo_mall/meiduo_mall/utils/fastdfs/`目录下，并修改文件的2个配置参数如下；
  
  ```python
  # 自定义日志文件存放目录，写自己的目录(必须存在)
  # base_path=<你的日志目录>
  base_path=/Users/weiwei/Desktop/
  
  # 指定tracker服务器的ip和端口，写自己的ubuntu的ip，端口固定22122不变
  # tracker_server=<你的ubuntu的ip>:22122
  tracker_server=192.168.203.161:22122
  ```
  
- 修改`meiduo_mis_sz37/meiduo_mall/meiduo_mall/utils/fastdfs/fastdfs_storage.py`文件如下；
  
  ```python
  """
  自定义文件存储后端，使得我们的image.url得出的结果前面拼接完整的fdfs请求url前缀;上传图片到fdfs；
  """
  # Storage：存储后端基类
  from django.core.files.storage import Storage
  from django.conf import settings
  from rest_framework.serializers import ValidationError
  from fdfs_client.client import Fdfs_client
  class FastDFSStorage(Storage):
  
      def open(self, name, mode='rb'):
          # 如果需要把上传的文件存储django本地，则需要在本地打开一个文件
          return None # 把图片上传fdfs，不是保存本地
  
      def save(self, name, content, max_length=None):
          # 保存文件逻辑：把文件上传到fdfs服务器上
          # name是文件名
          # content是上传的文件被封装成的文件对象
  
          # 调用fdfs客户端接口实现文件上传到fdfs
          conn = Fdfs_client('meiduo_mall/utils/fastdfs/client.conf')
          # 调用接口上传
          res = conn.upload_by_buffer(content.read())
          # res类型是dict
          # {
          #   'Group name': 'group1',
          #   'Uploaded size': '72.00KB',
          #   'Local file name': '1.jpg',
          #   'Status': 'Upload successed.',
          #   'Remote file_id': 'group1/M00/00/02/wKjLoV8OcG-AcxdDAAEh_koVzDo213.jpg',
          #   'Storage IP': '192.168.203.161'
          # }
          if res['Status'] != 'Upload successed.':
              # 说明上传失败！
              raise ValidationError("上传文件失败！")
  
          # fdfs文件标识，需要存储到mysql
          file_id = res['Remote file_id']
  
          return file_id # 文件存储后端save方法返回的结果就是存储到mysql中的数据
  
      def url(self, name):
          # 该函数决定了，ImageField.url的结果
          # name: 当前字段在数据库中存储的值
          # name = group1/M00/00/02/CtM3BVrPB4GAWkTlAAGuN6wB9fU4220429
          # "http://image.meiduo.site:8888/" + name
          return settings.FDFS_URL + name
  
      def exists(self, name):
          # 用于判断文件是否重复保存
          # return True # 文件已经存在
          # 当前业务返回False，表示"文件不保存本地，直接调用后续的save方法实现上传fdfs"
          return False # 文件不存在
  ```
```
  
  


```