``` 
docker安装
把 docker本地安装 文件夹复制到ubuntu, 然后进行如下操作:
# 进入该文件夹: 
cd docker本地安装
# 命令行执行该操作: 
sudo apt-key add gpg
sudo dpkg -i docker-ce_17.03.2~ce-0~ubuntu-xenial_amd64.deb
查看是否安装成功 sudo docker

docker操作
# 启动docker：$ sudo service docker start
# 重启docker ：$ sudo service docker restart
# 停止docker ：$ sudo service docker stop
# 状态：$ sudo service docker status
systemctl daemon-reload  重新加载配置

Docker 镜像操作
查看镜像列表：$ sudo docker image ls
相关参数：
* REPOSITORY：镜像所在的仓库名称 
* TAG：镜像标签 
* IMAGEID：镜像ID 
* CREATED：镜像的创建日期(不是获取该镜像的日期) 
* SIZE：镜像大小

从仓库拉取镜像
# 官方镜像
$ sudo docker image pull 镜像名称 或者 sudo docker image pull library/镜像名称
$ sudo docker image pull ubuntu 或者 sudo docker image pull library/ubuntu
$ sudo docker image pull ubuntu:16.04 或者 sudo docker image pull library/ubuntu:16.04
# 个人镜像
$ sudo docker image pull 仓库名称/镜像名称
$ sudo docker image pull itcast/fastdfs

删除镜像 ：sudo docker image rm 镜像名或镜像ID

Docker 容器操作
# 查看正在运行的容器 ：$ sudo docker container ls
# 查看所有的容器 ：$ sudo docker container ls --all

创建容器 ：sudo docker run [option] 镜像名 [向启动容器中传入的命令]
例：$ sudo docker run -dit --name=tracker --network=host -v /var/fdfs/tracker:/var/fdfs delron/fastdfs tracker
$ sudo docker run -dti --name=storage --network=host -e TRACKER_SERVER=tracker所在ip:22122 -v /var/fdfs/storage:/var/fdfs delron/fastdfs storage

常用可选参数说明：
* -i 表示以《交互模式》运行容器。
* -t 表示容器启动后会进入其命令行。加入这两个参数后，容器创建就能登录进去。即分配一个伪终端。
* --name 为创建的容器命名。
* -v 表示目录映射关系，即宿主机目录:容器中目录。注意:最好做目录映射，在宿主机上做修改，然后共享到容器上。 
* -d 会创建一个守护式容器在后台运行(这样创建容器后不会自动登录容器)。 
* -p 表示端口映射，即宿主机端口:容器中端口。
* --network=host 表示将主机的网络环境映射到容器中，使容器的网络与主机相同。

停止和启动容器
停止容器 ：$ sudo docker container stop 容器名或容器id
kill掉容器 :$ sudo docker container kill 容器名或容器id
启动容器 :$ sudo docker container start 容器名或容器id

删除容器 :sudo docker container rm 容器名或容器id(正在运行的容器无法直接删除。)

进入docker:docker exec -it [container_id/name] /bin/bash

容器制作成镜像
# 将容器制作成镜像
$ sudo docker commit 容器名 镜像名
# 镜像打包备份
$ sudo docker save -o 保存的文件名 镜像名
# 镜像解压
$ sudo docker load -i 文件路径/备份文件








```

