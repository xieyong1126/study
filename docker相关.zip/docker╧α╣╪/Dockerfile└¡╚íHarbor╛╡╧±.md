**Dockerfile**

```bash
#Harbor仓库/镜像/版本
#docker pull 192.168.208.127/vfibb/ubuntu:v1.1.1
FROM vfibb/ubuntu:v1.1.1
```

**/etc/docker/daemon.json**

```bash
{
"registry-mirrors":["http://192.168.208.127:80"],
"insecure-registries": ["192.168.208.127:80","192.168.208.127:443"]
}
#自动拉取镜像地址
#仓库地址

#加载配置
systemctl daemon-reload
#重启
systemctl restart docker

```

**Dockerfile构建镜像**

```bash
docker image build -t vfibb:1.0 ./
                      镜像名:版本  Dockerfile路径
```

