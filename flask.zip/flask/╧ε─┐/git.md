| 分支   | 作用                                              |
| ------ | ------------------------------------------------- |
| master | 主分支, 保留发布版本                              |
| dev    | 开发分支, 保留所有历史版本                        |
| f_xxx  | feature 功能特性分支, 实现功能开发                |
| b_xxx  | bug修复分支, 负责处理线上bug                      |
| r_xxx  | release 发布分支, 负责代码测试,bug修复,分包发布等 |

#### 项目经理

- 创建master/develop分支

- 部署项目到远程仓库

- 设置角色权限

- 审批合并请求

- 合并测试分支到主分支

  ``` bash
  # 项目经理-初始化
  git init
  git add .
  git commit -m xx
  git checkout -b develop
  ~ 在git服务器上在开发组中创建项目(远程仓库)
  git remote add origin xxxx
  git push -u origin --all
  git push -u origin --tags
  ~ 对master和develop分支进行访问限定
  ```

  

#### 开发者

- 创建自己的功能分支

- 在自己的功能分支上进行开发

- 提交合并请求

- 在维护分支和测试分支中对代码进行修改

  ``` bash
  git status #查看状态
  git branch #查看当前分支
  git branch -a #查看所有分支
  git branch -D master #删除本地分支
  git branch -r -d origin/branch-name #删除远程分支
  git push origin :branch-name #删除远程分支
  #？？？git checkout matsr #拉取远程分支
  git pull origin branch_name #本地分支推送到远程
  ```

  

```bash
git clone xx #克隆
#什么都不加：项目级别，global:用户级别,登陆这台计算机的用户，system:整台计算机，不管登陆那个帐号，不管哪个项目
git config [--global/--system] user.name 'xiexie'
git cinfig [--global/--system] user.email 'a@b.com'

# 创建develop并且切换到该分支，最后关联到远程的develop，相当于拉取远程分支
git checkout -b develop origin/develop

# 从develop克隆出功能分支f_detail，
git checkout -b f_detail

# 在功能分支上开发代码
git add .
git commit -m '描述'
git push
~ 发起合并请求

#冲突场景

# 分支A
0.切换到dev分支
git checkout develop
1. 新建分支演示冲突
git checkout -b f_a
2. 编写一段代码
3.将代码推送到远程

# 分支B
0.切换到dev分支
git checkout develop
1. 新建分支演示冲d
git checkout -b f_b
2. 相同地方-编写一段代码
3.将代码推送到远程


# 先让f_a用户合并代码
# 再让f_b用户合并代码 ---合并失败，有冲突，关闭合并请求

# 在B用户合并完出现冲突 -- meger按钮点击不了

# 合并之后解决冲突
#1.拉取并合并最新代码--本地代码合并
 git pull origin develop  
#2.查看冲突代码 
  git status
#3.修改冲突地方后提交并推送代码
#4.再次发起合并请求

```

``` python
# 集中测试和发布阶段
git checkout -b release_detail
git add .
git commit
git checkout develop
git merge release_detail  # 要求有develop合并权限
git checkout master 
git cherry-pick 版本号  # 将指定的版本合并到当前分支中
git push
git tag -a 0.1 -m xxx
git push --tags
git branch -d f_detail   # 删除本地分支
git push origin --delete f_detail  # 删除远程分支
```

