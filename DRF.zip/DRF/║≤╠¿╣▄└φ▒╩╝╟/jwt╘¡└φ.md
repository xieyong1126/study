##### JWT作用：保证数据的完整性！

JWT就相当于一个**令牌**，这个令牌具备以下2个特性：

- 0、令牌是**后端**签发给**用户**的

- 1、记录用户身份信息
- 2、可以被验证真伪

使用JWT这项技术，就可以实现**多点登陆**；

**多点登陆**：客户端在**任意一台服务端完成登陆**之后，服务端签发**令牌(token)**；之后，该用户可以**使用该令牌在任意其他的服务器中完成身份认证**！！



##### JWT实现原理

1、jwt令牌(token值)其实就是一个字符串

token字符串用**"点"**隔开分三段；并且是经过编码的！

```python
"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9.TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ"
```

2、三段组成

2.1 第一段字符串，称之为**头信息(header)**

```python
# python中的一个字典
header = {
  'typ': 'JWT', # 类型/格式
  'alg': 'HS256' # 哈希算法，使用该算法生成token字符串的第三部分
}

# 上述的字典数据经过编码后得出token字符串的头信息
"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
```

2.2 第二段字符串，称之为**载荷(payload)**

载荷信息就是存储的用户信息！

```python
# python中的一个字典，记录用户信息
payload = {
  "username": 'weiwei',
	"user_id": 1
}

# 上述的字典数据经过编码之后得出的token字符串的载荷信息
"eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9"
```

2.3 第三段字符串，称之为**签名(signature)**

签名的作用就是**验证整个token字符串的真伪**！

校验的逻辑：签发token的时候使用一个密钥生成签名部分，如果用户修改了token的header和payload信息，由于没有密钥，用户无法生成对应的第三部分签名数据；我们后台把用户的header和payload重新签发新的签名，如果header和payload没有被改动的话，新旧签名应该是一致！

```python
# 签名生成和校验的原理
# =======签名生成操作流程========
#  1、把token前两段字符串拼接(点隔开)，这个字符串称之为“信息摘要”
message = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9"
# 2、准备一个用户生成签名的密钥——该密钥保证生成的签名唯一，且不被篡改
secret = "FEWGHTrhty5hHY%HJ$uybyju46ju6juj5iu"
# 3、使用哈希/散列算法配合密钥得出签名
signature = HS256(message, secret)

# 得到了签名字符串
"TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ"


# =======签名校验操作流程========
token = "fewferwhjgbrehwgEGTTE.grbnehgbhtjuerw.gtrbwhguktbrhwgjktur"
# 1、把前端传过来的token中提取三段数据
header = "fewferwhjgbrehwgEGTTE"
payload = "grbnehgbhtjuerw"
signature = "gtrbwhguktbrhwgjktur"
# 2、把header和payload拼接，然后使用HS256配合密钥重写签发一个签名
message = header + '.' + payload
new_signature = HS256(message, secret)
# 3、把新旧签名比对，如果一致则说明数据没有被篡改
if signture == new_signature:
  # 没有篡改
else:
  # 被篡改了
```























