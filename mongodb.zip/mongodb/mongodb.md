安装：sudo apt-get install -y mongodb-org

查看帮助：mongod --help

启动：sudo service mongod start

停止：sudo service mongod stop

重启：sudo service mongod restart

查看进程：ps aux | grep mongod

配置文件：/etc/mongod.conf

默认端口：27017

日志:/var/log/mongodb.mongod.log



启动本地客户端：mongo

退出：exit  ctrl + c

