from scrapy_redis.spiders import RedisSpider


# 继承：RedisSpider
class MySpider(RedisSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""

    name = 'myspider_redis'

    # 代替了start_urls=[]
    # 以键值对的形式在redis数据库中添加起始url地址
    # lpush myspider:start_urls 起始url地址
    # lpush myspider:start_urls http://www.dmoz-odp.org/
    # 一旦开启爬虫，当redis中没有设置起始url地址的键值对信息的时候就会处于阻塞等待状态，直到有值才会执行爬虫
    redis_key = 'myspider:start_urls'

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(MySpider, self).__init__(*args, **kwargs)

    def parse(self, response):
        return {
            'name': response.css('title::text').extract_first(),
            'url': response.url,
        }

