from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class DmozSpider(CrawlSpider):
    """Follow categories and extract links."""
    # 爬虫名称
    name = 'dmoz'
    # 允许爬取的域名范围
    allowed_domains = ['dmoz-odp.org']
    # 起始url地址
    start_urls = ['http://www.dmoz-odp.org/']

    # 提取规则
    rules = [
        # 使用css样式进行url提取
        Rule(LinkExtractor(
            restrict_css=('.top-cat', '.sub-cat', '.cat-item')
        ), callback='parse_directory', follow=True),
    ]

    # 数据解析
    def parse_directory(self, response):
        for div in response.css('.title-and-desc'):
            yield {
                'name': div.css('.site-title::text').extract_first(),
                'description': div.css('.site-descr::text').extract_first().strip(),
                'link': div.css('a::attr(href)').extract_first(),
            }
