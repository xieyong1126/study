# Scrapy settings for example project
#
# For simplicity, this file contains only the most important settings by
# default. All the other settings are documented here:
#
#     http://doc.scrapy.org/topics/settings.html
#
SPIDER_MODULES = ['example.spiders']
NEWSPIDER_MODULE = 'example.spiders'

USER_AGENT = 'scrapy-redis (+https://github.com/rolando/scrapy-redis)'

# 将request转换为指纹
# 分布式爬虫：指纹去重类
DUPEFILTER_CLASS = "scrapy_redis.dupefilter.RFPDupeFilter"


# 分布式爬虫：request调度器
SCHEDULER = "scrapy_redis.scheduler.Scheduler"

# 表示是否持久化request队列和request指纹
SCHEDULER_PERSIST = True
# SCHEDULER_PERSIST = True 程序结束时不删除request的队列和指纹集合
# SCHEDULER_PERSIST = False 程序结束时会删除request的队列和指纹集合

# SCHEDULER_QUEUE_CLASS = "scrapy_redis.queue.SpiderPriorityQueue"
# SCHEDULER_QUEUE_CLASS = "scrapy_redis.queue.SpiderQueue"
# SCHEDULER_QUEUE_CLASS = "scrapy_redis.queue.SpiderStack"

ITEM_PIPELINES = {
    'example.pipelines.ExamplePipeline': 300,
    # 把item数据存入指定的redis数据库
    'scrapy_redis.pipelines.RedisPipeline': 400,
}

LOG_LEVEL = 'DEBUG'

# Introduce an artifical delay to make use of parallelism. to speed up the
# crawl.
DOWNLOAD_DELAY = 1

# redis连接信息
REDIS_URL = "redis://192.168.243.152:6379"
