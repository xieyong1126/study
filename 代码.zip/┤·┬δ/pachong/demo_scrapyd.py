import requests


def start_scrapyd_spider(project_name, spider_name):
    """
    使用scrapyd启动部署之后的爬虫
    :param project_name: 项目名称
    :param spider_name: 爬虫名称
    :return:
    """

    # 准备发送请求的url地址
    url = "http://localhost:6800/schedule.json"

    # 请求体参数
    data = {
        "project": project_name,
        "spider": spider_name
    }

    response = requests.post(url, data=data)

    print(response.text)


def stop_scrapyd_spider(project_name, jobid):
    """
    停止爬虫
    :param project_name: 项目名称
    :param jobid: 任务id
    :return:
    """
    # 准备url
    url = "http://localhost:6800/cancel.json"

    # 准备请求体数据
    data = {
        "project": project_name,
        "job": jobid
    }

    response = requests.post(url, data=data)

    print(response.text)


if __name__ == '__main__':
    start_scrapyd_spider("itcast1", "teacher")
    # stop_scrapyd_spider("itcast1", "83a83548e83b11eab4a4f21898247ec4")
