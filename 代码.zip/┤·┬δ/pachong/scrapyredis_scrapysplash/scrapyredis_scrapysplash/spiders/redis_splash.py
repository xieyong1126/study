# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
from scrapy_splash import SplashRequest


# 需求：scarpy_redis + scrapy_splash
class RedisSplashSpider(RedisSpider):
    name = 'redis_splash'
    allowed_domains = ['baidu.com']
    # start_urls = ['https://www.baidu.com/s?wd=python']
    redis_key = "rsurl"

    # lpush rsurl https://www.baidu.com/

    # 注意：直接在parse方法中发送SplashRequest请求
    def parse(self, response):
        url = "https://www.baidu.com/s?wd=python"
        yield SplashRequest(url=url,
                            callback=self.redis_splash_parse,
                            args={"wait": 10},
                            endpoint="render.html")

    def redis_splash_parse(self, response):
        with open("redis_splash.html", 'w') as f:
            f.write(response.body.decode())
