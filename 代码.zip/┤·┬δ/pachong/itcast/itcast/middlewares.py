# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html
import time

from scrapy import signals
from .settings import USER_AGENTS_LIST
import random


class UserAgentMiddleware(object):
    """随机UA下载中间件"""

    # 需求: 给请求对象添加一个随机的UA
    def process_request(self, request, spider):
        """拦截请求对象，设置UA,设置cookies,设置代理"""
        if spider.name == "teacher":
            # 随机获取一个UA
            user_agent = random.choice(USER_AGENTS_LIST)
            # 添加到请求对象中
            request.headers["User-Agent"] = user_agent

            # 注意：不需要返回，请求对象将传递到优先级更低的下载中间件或者下载器


class CheckUAMiddleware(object):

    def process_response(self, request, response, spider):
        """拦截响应，请求对象"""

        if spider.name == "teacher":
            UA = request.headers["User-Agent"]
            print("===>", UA)
            with open("ua.txt", 'w') as f:
                f.write(UA.decode())
            # 注意：返回response 将响应交付给引擎，进而传入parse解析函数
            return response


class ProxyMiddleware(object):

    def process_request(self, request, spider):
        """拦截请求对象，设置免费代理ip"""

        # 1.准备代理
        proxy_str = "http://39.108.92.182:8888"
        # 2.设置meta字典的proxy值
        request.meta["proxy"] = proxy_str


from selenium import webdriver


# 1.利用selenium模拟登录
# 2.利用selenium提取cookie
def cookie_dict_from_selenium():
    """提取登录成功之后的cookie字典"""

    # 1.浏览器驱动对象添加可选项-无界面浏览器
    option = webdriver.ChromeOptions()
    option.add_argument("--headless")
    option.add_argument("--disabel-gpu")
    # 2.创建浏览器驱动对象
    # 注意点：需要设置完整的路径
    driver = webdriver.Chrome("/Users/chenqian/Desktop/driver/chromedriver", chrome_options=option)

    # 3.利用驱动对象发送登录页面请求: https://github.com/login
    driver.get("https://github.com/login")

    # 4.模拟输入账号密码点击登录按钮
    driver.find_element_by_id("login_field").send_keys("279752917@qq.com")
    time.sleep(1)
    driver.find_element_by_id("password").send_keys("XIAOxiaozicq520")
    time.sleep(1)
    driver.find_element_by_name("commit").click()

    # 5.延迟等待一会，提取cookie字典
    time.sleep(2)
    cookie_dict = {cookie["name"]: cookie["value"] for cookie in driver.get_cookies()}
    # 6.退出浏览器驱动
    driver.quit()
    # 7.返回cookie字典
    return cookie_dict


class GithubLoginMiddleware(object):

    # 3.下载中间件中拦截请求，往请求中添加cookie
    def process_request(self, request, spider):
        # 判断如果是起始URL地址，我们才设置cookie
        if request.url == spider.start_urls[0]:
            request.cookies = cookie_dict_from_selenium()
