# -*- coding: utf-8 -*-
import json
import scrapy


class JinshanSpider(scrapy.Spider):
    name = 'jinshan'
    allowed_domains = ['iciba.com']
    # 起始URL地址
    start_urls = ['http://fy.iciba.com/ajax.php?a=fy']

    # 1.重写start_requests方法
    def start_requests(self):

        # 2.构建请求体字典
        form_data = {
            "f": "auto",
            "t": "auto",
            "w": "你好"
        }

        # 3.发送post请求，并且指明响应解析函数，交付给引擎
        for url in self.start_urls:
            # scrapy.Request(url=url, body=json.dumps(form_data), method="POST", callback=self.parse)
            # 构建post请求对象
            post_request = scrapy.FormRequest(url=url,
                                              formdata=form_data,
                                              callback=self.parse)
            yield post_request

    def parse(self, response):

        # 将响应html转换成字典
        ret_dict = json.loads(response.body.decode())

        # 提取数据
        try:
            ret = ret_dict["content"]["out"]
        except Exception as e:
            ret = ret_dict["content"]["word_mean"]

        print("====", ret)
