# -*- coding: utf-8 -*-
import scrapy


class Github1Spider(scrapy.Spider):
    name = 'github1'
    allowed_domains = ['github.com']
    # 登录页面作为起始URL地址
    start_urls = ['https://github.com/login']

    # 需求：找到登录页面的form表单，使用scrapy完成表单内容的填充操作
    # 利用起始URL地址发送GET请求，获取页面的响应response

    # 1.解析响应
    def parse(self, response):
        # 2.利用from_response方法添加表单
        # response 登录页面的响应
        # formxpath 从登录页面的响应中提取到form表单
        # formdata 找到表单中的input输入框按照name名字将字典对应的value进行表单自动填充
        # callback 登录成功后的响应解析函数
        # 注意：在前端的form表单中已经写好请求的url地址 https://github.com/session
        login_request = scrapy.FormRequest.from_response(response,
                                                         formxpath='//div[@id="login"]/form',
                                                         formdata={"login": "279752917@qq.com",
                                                                   "password": "XIAOxiaozicq520"},
                                                         callback=self.login_parser)
        yield login_request

    def login_parser(self, response):
        with open("github1.html", 'w', encoding="utf-8") as f:
            f.write(response.body.decode())
