# -*- coding: utf-8 -*-
import scrapy


class GithubselenimSpider(scrapy.Spider):
    name = 'githubselenim'
    allowed_domains = ['github.com']

    # 需求：起始URL地址是需要携带cookie的
    # 1.利用selenium模拟登录
    # 2.利用selenium提取cookie
    # 3.下载中间件中拦截请求，往请求中添加cookie
    # 4.保存响应页面
    start_urls = ['https://github.com/TmacChenQian']

    def parse(self, response):
        with open("github77.html", 'w') as f:
            f.write(response.body.decode())
