# -*- coding: utf-8 -*-
import scrapy


class GithubSpider(scrapy.Spider):
    name = 'github'
    allowed_domains = ['github.com']
    # 起始url地址为个人中心页面
    start_urls = ['https://github.com/TmacChenQian']

    # 1.重写父类的start_requests方法
    def start_requests(self):
        # 2.复制登录成功后的cookie字符串
        cookie_str = "_ga=GA1.2.789897426.1553919763; tz=Asia%2FShanghai; _octo=GH1.1.736727965.1553919776; _device_id=8bfbcc32fc3cfba7d8aa2a850386510b; tz=Asia%2FShanghai; _gat=1; has_recent_activity=1; user_session=qAm7VBWepRhhfuY07RrRIuz5YNRQrw7muW75NRmj3dZU4bmk; __Host-user_session_same_site=qAm7VBWepRhhfuY07RrRIuz5YNRQrw7muW75NRmj3dZU4bmk; logged_in=yes; dotcom_user=TmacChenQian; _gh_sess=1nCiaR5uN6IhOOI7ViAjjZPS2odz%2B17wC6NYIM7Bles5q5Z%2F5F3SwKrgs4HCnydlK57EhwDDRe%2F0uqo7f8gOYgOGF40pHJCc4%2B3kdiI2hiALpS3Rg1yM0oZyiet4Bos8vWK0N8rnVz0DkseY7D6ISJCilvqfKeQET9pKn4cU6PQW2YHvw85zke7OFp5h5DaF6ngTBPNiMOX30OurWSvD4iRdlkCG5nPFixmaMWKIIZp9CQisLYOjE2YrI4TH0qca4lDIC1YDb3yG%2BoEeiOqWS0f5GdK094taYaxSTl5d2QG6QAFXH%2BD%2BNFhgIagcdobj0yvv%2FLMPobhenmmMxz6PXzt8RzouN451SWlXOseKPz3NzYJ%2BIKsgtJpAU%2BXs3zfWn4mZwir5jtotb8rIgLOKCEpsIYXvfjFBnrHLE7M3e8uJVwd%2B6eY7Y6gHvkB4dflX4TrBorMH1qqpkRw4UZK4UwiIPptcR3o9ddHpCmvtYceqjcevABn7dC4D6mrMaNV50CfxaAiimfHxP%2BgalT4UaFi2aTAhKbEKkYdEw%2BdQvCAN4N9ic%2B%2B51Jtrvk5qUxph63swYkMqhmg3jhP1P7lBJrT%2BBaWUIGZ8d8gPlUyJnFJ3iBT81gycagtqzttREKRCdIQwznEHARIgKIdItI2MjJvE1la5KSVeyOsO9KeLf3JB7DpG4PC9mqmmV8ZChE%2FaK5DRD3dK1qozLFX7WO%2FBLfoxfPAmJs1DQ38DmznTW5qAnKNMGGHD0ZoLpk6vnMQAUvXemVvkddr2egObjL3%2B8G4iPJJwc5TCTen58qh6xhV2lODLISzSvbbBp0ZR%2BXbZEYQ2cHhCjfRanphBWXD%2BA2jlKo35i9xtlfKY5HcKyJzldqYULLnLVxKEdUbpwLRgdcE9Xa7rwOmPf1NZ23O4MnrO87aHAw4JXCl7pZbxn1JmVCRQYqHem5ZwM5oEp8vo4ZQX10gb9gm%2B%2Fz1R1iKyz3PFZPf7vV2eXZW5cyKOo4PuDRYrQ9JhuJOgWkBRQmIiS7xiygpPYznGJ0pnEmMhEzOSGuBLLL55jHVMgStjo4NVT8F6NNIETiFEzIjKKqXp%2BuXGo6PQH4MWWg2xRQWE1%2FAxRZ8bWKyo37bSU56EaF3ju3mOF6HvRa5HAhjkfGn%2Bk90iploTqfyqfk95BDu7FMTzIocUigbz--DKneYVmPTvPrHPQM--5jQd1%2BPSeZgZ%2BTmJD95G4w%3D%3D"
        # 3.将cookie字符串转换成字典
        cookie_dict = {cookie.split("=")[0]: cookie.split("=")[1] for cookie in cookie_str.split("; ")}
        # 4.构建request请求，携带cookie，并且交付给引擎
        for url in self.start_urls:
            login_request = scrapy.Request(url=url,
                                           callback=self.parse,
                                           cookies=cookie_dict)
            yield login_request

    # 5.解析响应
    def parse(self, response):

        with open("github.html", "w", encoding="utf-8") as f:
            f.write(response.body.decode())
