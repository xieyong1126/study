# -*- coding: utf-8 -*-
import time

import scrapy
from ..items import JobItem


class JobSpider(scrapy.Spider):
    """163招聘的爬虫类"""

    # 爬虫名字
    name = 'job'
    # 爬虫运行爬取的域名范围
    allowed_domains = ['163.com']
    # 起始URL地址
    start_urls = ['https://hr.163.com/position/list.do']

    # 响应解析函数
    def parse(self, response):
        # 1.提取所有招聘信息的tr标签
        # 注意：分组的时候不需要extract()
        tr_list = response.xpath("//table[@class='position-tb']//tr")

        # 1.1 去除空的标签[下标为偶数的为空标签]
        tr_list = [tr for tr in tr_list if tr_list.index(tr) % 2 != 0]

        # 2.遍历提取每一组中的招聘信息标题
        for tr in tr_list:
            item = JobItem()
            item["title"] = tr.xpath("./td[1]/a/text()").extract_first()

            print(item)

        # 3.获取下一个url地址
        # ?currentPage=2
        next_url = response.xpath('//a[text()=">"]/@href').extract_first()

        # 4.判断是否是最后一页
        if next_url != "javascript:void(0)":
            # 防止爬虫被封
            time.sleep(2)

            # 4.1 拼接完整的url地址
            # https://hr.163.com/position/list.do?currentPage=1
            next_full_url = self.start_urls[0] + next_url

            # 5.构建下一页的请求，指定下一页的响应解析函数，并且将请求交付给引擎 yield
            # url 请求目标url
            # callback 回调函数，下一页的响应交付给那个函数进行解析
            next_request = scrapy.Request(url=next_full_url, callback=self.parse)

            yield next_request
