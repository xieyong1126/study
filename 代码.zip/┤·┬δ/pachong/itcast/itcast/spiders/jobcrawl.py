# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class JobcrawlSpider(CrawlSpider):
    name = 'jobcrawl'
    allowed_domains = ['163.com']
    start_urls = ['https://hr.163.com/position/list.do']

    # 详情页的URL地址：https://hr.163.com/position/detail.do?id=23679
    # 下一页的URL地址：https://hr.163.com/position/list.do?currentPage=2
    # 从起始页的URL地址对应的response的html中进行匹配，根据正则提取url
    rules = (
        # 详情页URL规则
        Rule(LinkExtractor(allow=r'/position/detail.do/?id=\d+'), callback="parse_item"),
        # 下一页URL规则
        Rule(LinkExtractor(allow=r'/?currentPage=\d+'), follow=True),
    )

    def parse_item(self, response):
        item = {}
        print("===>")
        item["title"] = response.xpath("//h2[@class='job-title']/text()").extract_first()
        print(item)
        yield item
