# -*- coding: utf-8 -*-
import scrapy
# 导入自定义模型类
from ..items import ItcastItem


# 继承：scrapy.Spider
class TeacherSpider(scrapy.Spider):
    # 爬虫名字[后续启动爬虫需要用到]
    name = 'teacher'
    # 爬虫运行抓取的域名范围
    allowed_domains = ['itcast.cn']
    # 起始URL地址
    start_urls = ['http://www.itcast.cn/channel/teacher.shtml']

    # 将起始URL地址对应的响应进行解析
    # 方法的名字不能随意改动必须是：parse
    # response 响应对象，响应html是从body属性中提取
    def parse(self, response):
        """
        解析响应提取信息
        :param response: 响应对象
        :return:
        response 响应对象，响应html是从body属性中提取
        response 可以直接使用xpath语法提取数据
        """
        # 1.提取包含所有老师信息的li标签
        li_list = response.xpath('//div[@class="tea_con"]//li')

        # 2.遍历所有li标签，提取：名字，级别，描述，图片url
        for li in li_list:
            # 使用xpath语法返回是选择器对象Selector
            # <Selector xpath='//div[@class="tea_con"]//li' data='<li>\r\n\t\t\t\t\t\t<img data-original="/imag...'>
            # 从选择器对象中提取数据：extract() or extract_first()

            # 根据自定义模型类ItcastItem创建模型对象
            item = ItcastItem()
            # 老师的名字
            item["name"] = li.xpath('.//h3/text()').extract_first()
            # 老师的级别
            item["level"] = li.xpath('.//h4/text()').extract_first()
            # 描述信息
            item["desc"] = li.xpath('.//p/text()').extract_first()
            # 图片URL
            item["img"] = li.xpath('.//img/@data-original').extract_first()

            # print(item)
            # 返回数据给引擎，引擎就会将数据交付给pipeline
            # next(生成器对象)
            # 自定义的模型类，字典，请求对象
            yield item
