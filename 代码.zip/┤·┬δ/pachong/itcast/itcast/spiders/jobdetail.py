# -*- coding: utf-8 -*-
import scrapy
from ..items import JobDetailItem


class JobdetailSpider(scrapy.Spider):
    name = 'jobdetail'
    allowed_domains = ['163.com']
    # 起始URL地址
    # 细节：起始URL地址不会去重
    start_urls = ['https://hr.163.com/position/list.do']

    # 响应解析函数
    def parse(self, response):
        # 1.提取所有招聘信息的tr标签
        # 注意：分组的时候不需要extract()
        tr_list = response.xpath("//table[@class='position-tb']//tr")

        # 1.1 去除空的标签[下标为偶数的为空标签]
        tr_list = [tr for tr in tr_list if tr_list.index(tr) % 2 != 0]

        # 2.遍历提取每一组中的招聘信息标题
        for tr in tr_list:
            item = JobDetailItem()
            # 首页的招聘标题
            item["title"] = tr.xpath("./td[1]/a/text()").extract_first()

            # 获取详情页的跳转URL地址
            # /position/detail.do?id=4874
            detail_url = tr.xpath("./td[1]/a/@href").extract_first()

            # 拼接完整的url地址
            detail_url = "https://hr.163.com/" + detail_url

            # 构建详情页的请求对象，指明请求对应的响应的解析函数，并且交付给引擎 yield
            # 将首页中的item传入到detail_parse中，进行数据的保存
            # meta 字典类型参数，在不同解析函数之间进行数据传递
            detail_request = scrapy.Request(url=detail_url,
                                            callback=self.detail_parse,
                                            meta={"item": item})

            yield detail_request

    def detail_parse(self, response):
        """
        处理详情页的数据解析
        :param response: 详情页的响应对象
        :return:
        """

        # 1.获取传过来的item对象
        item = response.meta["item"]

        # 2.提取响应中的发布时间保存到item中
        item["date"] = response.xpath("//p[@class='post-date']/text()").extract_first()

        print(item)
        yield item



