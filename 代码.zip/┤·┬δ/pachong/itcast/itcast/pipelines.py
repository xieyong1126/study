# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import json
from pymongo import MongoClient


class ItcastPipeline(object):
    """将teacher爬虫数据保存到Json文件中"""

    def open_spider(self, spider):
        """爬虫启动的时候仅调用一次，完成一些初始化工作"""
        if spider.name == "teacher":
            self.f = open("teacher.json", "w")

    # 方法名字必须是:process_item
    def process_item(self, item, spider):
        """
        处理解析函数返回的item数据
        :param item: 自定义的模型对象,本质还是字典
        :param spider: 爬虫对象，可以通过spider.name区分不同的爬虫，进行数据存储
        :return: 必须将item再次返回给引擎
        """
        if spider.name == "teacher":
            # 将模型对象转换成字典
            item_dict = dict(item)
            # 字典转换成json字符串
            item_json = json.dumps(item_dict, ensure_ascii=False, indent=2)
            self.f.write(item_json + ",\n")

        return item

    def close_spider(self, spider):
        """爬虫结束的时候仅调用一次，完成一些收尾工作"""
        if spider.name == "teacher":
            self.f.close()


class TeacherMongodbPipeline(object):

    def open_spider(self, spider):

        if spider.name == "teacher":
            # 连接mongodb数据库
            # 获取mongodb客户端对象
            client = MongoClient()
            # 获取mongodb集合对象
            self.teacher = client["itcast"]["teacher"]

    def process_item(self, item, spider):
        if spider.name == "teacher":
            # 将模型对象转换成字典
            item_dict = dict(item)
            # 将字典写入mongodb
            self.teacher.insert_one(item_dict)

        # 返回itme作用：将数据交付给优先级更低的管道进行进一步数据处理
        return item
