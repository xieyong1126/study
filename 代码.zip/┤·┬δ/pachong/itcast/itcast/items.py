# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


# 继承：scrapy.Item
class ItcastItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    # 自定义模型类的字段
    # 注意：parse方法中提取的字段名称必须和自定义模型类中字段名保持一致
    # 名字
    name = scrapy.Field()
    # 级别
    level = scrapy.Field()
    # 描述
    desc = scrapy.Field()
    # 图片url
    img = scrapy.Field()


class JobItem(scrapy.Item):
    """163招聘首页模型类"""
    # 自定义的字段
    title = scrapy.Field()


class JobDetailItem(scrapy.Item):
    """163招聘详情页的模型类"""
    # 首页的标题
    title = scrapy.Field()
    # 详情页的发布时间
    date = scrapy.Field()
