# -*- coding: utf-8 -*-
import time
from copy import deepcopy
import scrapy
from scrapy_redis.spiders import RedisSpider


# 修改继承类为：RedisSpider
class BookSpider(RedisSpider):
    # 爬虫名称
    name = 'book'
    # 允许爬取的域名范围
    allowed_domains = ['bookschina.com']
    # 起始URL地址-图书分类
    # start_urls = ['http://www.bookschina.com/books/kinder/']
    # 修改起始url地址为：redis_key
    redis_key = "bookurl"
    # lpush bookurl http://www.bookschina.com/books/kinder/
    # 根路径
    base_url = "http://www.bookschina.com"

    # 起始URL地址的响应解析函数
    def parse(self, response):
        # 先分组，获取所有的大分类h2标签
        h2_list = response.xpath('//div[@class="categoriesList"]//h2')
        # 遍历h2标签，提取大分类数据值
        # ["文书", '科学']
        # ["a", "b"]  ["c", "d"]
        for h2 in h2_list[:1]:
            # 数据字典
            item = {}
            # 获取所有大分类
            item["b_category"] = h2.xpath("./a/text()").extract_first()

            # 获取小分类的所有li标签
            # 注意：大分类的第一个兄弟节点就是小分类的列表
            li_list = h2.xpath('./following-sibling::ul[1]/li')


            # 遍历li标签，提取小分类数据
            for li in li_list[:1]:
                # 提取小分类

                item["s_category"] = li.xpath("./a/text()").extract_first()

                # 提取图书列表页的URL地址
                item["booklist_url"] = self.base_url + li.xpath('./a/@href').extract_first()


                # 构建图书列表页的请求，设置列表页的回调函数，利用meta属性传递item对象，将请求交付给引擎
                yield scrapy.Request(url=item["booklist_url"],
                                                  callback=self.booklist_parse,
                                                  meta={"item": deepcopy(item)})

    def booklist_parse(self, response):
        """图书列表页数据提取"""

        # 取出item对象
        item = response.meta["item"]
        #  {"文学"， "a}

        # 1.提取包含所有数据信息的所有li标签
        li_list = response.xpath('//div[@class="bookList"]//li')
        # item = {"文学"， "a"， "一本书的所有信息"}
        # item = {"文学"， "a"， "二本书的所有信息"}

        # 2.遍历li标签提取数据信息
        for li in li_list:
            # 图书名称
            item["book_name"] = li.xpath('.//h2[@class="name"]/a/text()').extract_first()

            # 图书作者
            item["author_name"] = li.xpath('.//a[@class="author"]/text()').extract_first()

            # 图片地址
            item["img_url"] = li.xpath('.//img[@class="lazyImg"]/@data-original').extract_first()

            # 出版日期
            item["pub_date"] = li.xpath('.//span[@class="pulishTiem"]/text()').extract_first()

            # 出售价格
            item["sell_price"] = li.xpath('.//span[@class="sellPrice"]/text()').extract_first()

            # 折扣
            item["discount"] = li.xpath('.//span[@class="discount"]/text()').extract_first()

            # 描述信息
            item["desc"] = li.xpath('.//p[@class="recoLagu"]/text()').extract_first()

            # 将模型对象item交付给引擎
            yield item

        # 爬取下一页数据
        # 获取下一页的url地址
        # /kinder/27230000_0_0_11_0_1_2_0_0/
        next_url = response.xpath("//li[@class='next']/a/@href").extract_first()

        # 返回的选择器对象
        # next_url = response.xpath("//li[@class='next']/a/@href")
        # 判断是否是最后一页
        if next_url != None:
            # 方案1：
            # full_url = self.base_url + next_url
            # 构建下一页的请求，并且指明解析函数，传递item参数，交付给引擎
            #
            # yield scrapy.Request(url=full_url,
            #                callback=self.booklist_parse,
            #                meta={"item": item})

            # 防止ip被封
            time.sleep(3)

            # 方案2：在页面的响应对象的基础上继续爬取下一页
            yield response.follow(url=next_url, callback=self.booklist_parse, meta={"item": item})
