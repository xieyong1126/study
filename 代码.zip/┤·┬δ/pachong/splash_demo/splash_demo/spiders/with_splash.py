# -*- coding: utf-8 -*-
import scrapy
from scrapy_splash import SplashRequest


class WithSplashSpider(scrapy.Spider):
    name = 'with_splash'
    allowed_domains = ['baidu.com']
    start_urls = ['http://baidu.com/s?wd=python']

    # 重写start_requests方法，发送splash请求，获取渲染之后的网页源代码
    def start_requests(self):
        yield SplashRequest(url=self.start_urls[0],  # 起始url地址
                            callback=self.splash_parse,  # 回调函数
                            args={"wait": 10},  # 等待时长 单位s
                            endpoint="render.html")  # 固定参数，获取渲染之后的网页源代码

    def splash_parse(self, response):
        with open("with_splash.html", 'w') as f:
            f.write(response.body.decode())
