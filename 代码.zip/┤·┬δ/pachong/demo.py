import time
from redis import StrictRedis

# 默认情况下，redis的通知事件是关闭的，在终端执行以下命令开启：
# 提前执行：redis-cli config set notify-keyspace-events KEA

# 创建redis对象
# redis = StrictRedis(host=ip, port=port, db=0, decode_responses=True)
redis = StrictRedis()

# 创建消息订阅对象
pubsub = redis.pubsub()

# redis.setex("pay", 60 * 2, "还未支付")
# 支付任务-2小时过期

# setex
# 设置订阅的消息类型
# 0代表订阅那个数据库的通知
# *所有通知
pubsub.psubscribe('__keyspace@0__:*')
print("开始循环监听消息")

while True:
    # 获取消息
    message = pubsub.get_message()
    # 打印消息
    if message:
        print(message)
    else:
        time.sleep(0.01)
