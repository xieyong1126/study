# 隐私配置信息的环境变量名称
EXTRA_ENV_COINFIG = "ENV_CONFIG"

# 短信验证码过期时长 单位s
APP_SMSCODE_EXPIRE = 300

# 用户模块URL前缀
USER_URL_PREFIX = '/app'

# 首页展示 每页的文章数量
HOME_PRE_PAGE = 20