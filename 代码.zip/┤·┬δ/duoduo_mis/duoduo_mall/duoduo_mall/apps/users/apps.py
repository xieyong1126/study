from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'duoduo_mall.apps.users'
