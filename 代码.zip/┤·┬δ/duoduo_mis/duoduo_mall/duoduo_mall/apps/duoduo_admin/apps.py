from django.apps import AppConfig


class MeiduoAdminConfig(AppConfig):
    name = 'duoduo_admin'
