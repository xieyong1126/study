from rest_framework.viewsets import ModelViewSet
from goods.models import *
from duoduo_admin.serializers.brands_serializers import *
from duoduo_admin.utils.pages import MyPage

class BrandModelViewSet(ModelViewSet):

    queryset = Brand.objects.all()
    serializer_class = BrandModelSerializer

    pagination_class = MyPage
