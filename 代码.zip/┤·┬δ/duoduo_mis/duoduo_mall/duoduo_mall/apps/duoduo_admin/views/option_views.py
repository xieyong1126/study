from rest_framework.viewsets import ModelViewSet
from goods.models import SpecificationOption,GoodsSpecification
from duoduo_admin.serializers.option_serializers import *
from duoduo_admin.utils.pages import MyPage

class OptionViewSet(ModelViewSet):

    queryset = SpecificationOption.objects.all()
    serializer_class = OptionModelSerializer

    pagination_class = MyPage


class optionsimpleViewSET(ModelViewSet):
    queryset = GoodsSpecification.objects.all()
    serializer_class = GoodsSpeModelSerializer



