from django.test import TestCase

# Create your tests here.
# import base64
#
# data = b'{"typ":"JWT", "alg":"HS256"}'
#
# header = base64.b64encode(data).decode()
# print(header)
#
# import hmac,hashlib
#
# key = b'dsdsdfsdfsdfsdfsdf'
#
# token = hmac.new(key=key,msg=header.encode(),digestmod=hashlib.sha3_256)
# print(token)

# from datetime import date,datetime
#
#
# new_date = datetime.now()
#
# print(new_date,type(new_date))