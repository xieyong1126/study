#! /bin/bash

mysql -uroot -pmysql -h192.168.203.156 -D meiduo_mall_db < ./areas.sql
