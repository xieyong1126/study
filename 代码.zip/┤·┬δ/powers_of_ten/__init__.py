# 导入函数:
from pymysql import install_as_MySQLdb

# 调用该函数:
install_as_MySQLdb()
