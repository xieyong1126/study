#!/bin/bash

mysql -h127.0.0.1 -uroot -pmysql powers_of_ten < data.sql