import json

from django.shortcuts import render
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet

from person.models import User
from recruit.models import City,Enterprise,Recruit
# Create your views here.
from .serializers import EnterpriseSerializer2,CitySerializer,EnterpriseSerializer,RecruitSerializer
# 热门城市
class HotCityListView(APIView):

    def get(self, requset):

        city = City.objects.filter(ishot=1)

        serializer = CitySerializer(city, many=True)

        return Response(serializer.data)


# 最新职位接口
class LatestRecruitAPIView(APIView):

    def get(self,request):

        recruits = Recruit.objects.filter().order_by('-id')[0:4]

        serializer = RecruitSerializer(recruits, many=True)

        return Response(serializer.data)


# 推荐职位
class RecommendRecruitAPIView(APIView):
    def get(self,request):

        recruit = Recruit.objects.filter(state=1)[:4]

        serializer = RecruitSerializer(recruit, many=True)

        return Response(serializer.data)

# 热门企业
class HotEnterpriseAPIView(APIView):

    def get(self,request):

        enterprise = Enterprise.objects.all()

        serializer = EnterpriseSerializer(enterprise, many=True)

        return Response(serializer.data)

# 职位详情
class RecruitDetailsAPIView(APIView):

    def get(self, request, pk):

        recruit = Recruit.objects.get(pk=pk)

        serializer = RecruitSerializer(recruit)

        return Response(serializer.data)

# 企业详情
class EnterpriseDetailsAPIView(APIView):

    def get(self, request, pk):

        recruit = Enterprise.objects.get(pk=pk)

        serializer = EnterpriseSerializer2(recruit)

        return Response(serializer.data)


# 搜索职位
class SearchAPIView(APIView):

    def post(self, request):

        # 接收参数
        dict = json.loads(request.body.decode())
        cityname = dict.get('cityname')
        keyword = dict.get('keyword')

        if cityname and keyword:

            recruit = Recruit.objects.filter(city=cityname,jobname__contains=keyword)

            serializer = RecruitSerializer(recruit, many=True)

            return Response(serializer.data)

        elif cityname:

            recruit = Recruit.objects.filter(city=cityname)

            serializer =RecruitSerializer(recruit, many=True)

            return Response(serializer.data)

        else:

            recruit = Recruit.objects.filter(jobname__contains=keyword)

            serializer = RecruitSerializer(recruit, many=True)

            return Response(serializer.data)


# 增加企业访问次数
class VisitEnterpriseAPIView(APIView):

    def put(self, request, pk):

        enterprise = Enterprise.objects.get(pk=pk)

        enterprise.visits = enterprise.visits+1

        enterprise.save()

        return Response({"message":"更新成功",
                         "success": True})

# 增加职位访问次数
class VisitRecruitsAPIView(APIView):

    def put(self, request, pk):

        recruit = Recruit.objects.get(pk=pk)

        recruit.visits = recruit.visits+1

        recruit.save()

        return Response({"message":"更新成功","success":True})

# 收藏公司
class CollectionEnterpriseAPIView(APIView):

    def post(self, request, pk):

        enterprise = Enterprise.objects.get(id=pk)

        user = User.objects.get(username=request.user.username)

        enterprise.users.add(user)

        enterprise.save()

        return Response({
            "message":"收藏成功",
            "success": True
        })

# 取消收藏公司
class CancelCollectEnterpriseAPIView(APIView):

    def post(self, request, pk):

        enterprise = Enterprise.objects.get(id=pk)

        user = User.objects.get(username=request.user.username)

        enterprise.users.remove(user)

        enterprise.save()

        return Response({
            "message": "取消收藏",
            "success": True
        })


# 收藏职位
class CollectRecruitAPIView(APIView):

    def post(self, request, pk):

        recruit = Recruit.objects.get(id=pk)

        user = User.objects.get(username=request.user.username)

        recruit.users.add(user)

        recruit.save()

        return Response({
            "message": "收藏成功",
            "success": True
        })

# 取消收藏职位
class CancelCollectRecruitAPIView(APIView):

    def post(self, request, pk):
        recruit = Recruit.objects.get(id=pk)

        user = User.objects.get(username=request.user.username)

        recruit.users.remove(user)

        recruit.save()

        return Response({
            "message": "取消收藏",
            "success": True
        })