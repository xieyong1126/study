from django.urls import re_path
from . import views
from rest_framework.routers import DefaultRouter

urlpatterns = [
    # 热门城市
    re_path(r'^city/hotlist/$', views.HotCityListView.as_view()),
    # 最新职位
    re_path(r'^recruits/search/latest/$', views.LatestRecruitAPIView.as_view()),
    # 推荐职位
    re_path(r'^recruits/search/recommend/$', views.RecommendRecruitAPIView.as_view()),
    # 热门企业
    re_path(r'^enterprise/search/hotlist/$', views.HotEnterpriseAPIView.as_view()),
    # 职位详情
    re_path(r'^recruits/(?P<pk>\d+)/$', views.RecruitDetailsAPIView.as_view()),
    # 企业详情
    re_path(r'^enterprise/(?P<pk>\d+)/$', views.EnterpriseDetailsAPIView.as_view()),
    # 搜索职位
    re_path(r'recruits/search/city/keyword/$', views.SearchAPIView.as_view()),
    # 增加企业访问次数
    re_path(r'enterprise/(?P<pk>\d+)/visit/$', views.VisitEnterpriseAPIView.as_view()),
    # 增加职位访问次数
    re_path(r'recruits/(?P<pk>\d+)/visit/$', views.VisitRecruitsAPIView.as_view()),
    # 收藏公司
    re_path(r'enterprise/(?P<pk>\d+)/collect/$', views.CollectionEnterpriseAPIView.as_view()),
    # 取消收藏公司
    re_path(r'enterprise/(?P<pk>\d+)/cancelcollect/$', views.CancelCollectEnterpriseAPIView.as_view()),
    # 收藏职位
    re_path(r'recruits/(?P<pk>\d+)/collect/$', views.CollectRecruitAPIView.as_view()),
    # 取消收藏职位
    re_path(r'recruits/(?P<pk>\d+)/cancelcollect/$', views.CancelCollectRecruitAPIView.as_view()),

]

# # 收藏或取消收藏公司
# router = DefaultRouter()
#
# router.register(r'enterprise', views.CollectionEnterpriseViewSet, basename='enterprise')
#
# urlpatterns += router.urls