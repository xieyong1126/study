from django.apps import AppConfig


class RecruitConfig(AppConfig):
    name = 'recruit'
