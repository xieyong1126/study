from rest_framework import serializers

from .models import City,Recruit,Enterprise

# 热门城市
class CitySerializer(serializers.ModelSerializer):

    class Meta:
        model = City
        fields = ('id', 'name', 'ishot')

# 企业
class EnterpriseSerializer(serializers.ModelSerializer):

    class Meta:
        model = Enterprise
        fields = ('id', 'name', 'labels', 'logo', 'recruits', 'summary')
        # fields = '__all__'



# 职位
class RecruitSerializer(serializers.ModelSerializer):

    enterprise = EnterpriseSerializer(Enterprise.objects.all())

    class Meta:
        model = Recruit
        fields = '__all__'


# 企业详情
class EnterpriseSerializer2(serializers.ModelSerializer):

    recruits = RecruitSerializer(many=True)
    users = serializers.PrimaryKeyRelatedField(read_only=True, many=True)

    class Meta:
        model = Enterprise
        # fields = ('id', 'name', 'labels', 'logo', 'recruits', 'summary')
        fields = '__all__'