from django.urls import re_path
from . import views

urlpatterns = [
    re_path(r'^spit/$', views.SpitListView.as_view()),
    re_path(r'^spit/(?P<id>\d+)/collect/$', views.SpitCollectView.as_view()),
    re_path(r'^spit/(?P<id>\d+)/updatethumbup/$', views.SpitThumbupView.as_view()),
    re_path(r'^spit/(?P<id>\d+)/$', views.SpitDetailView.as_view()),
    re_path(r'^spit/(?P<id>\d+)/children/$', views.SpitCommentView.as_view()),
    # re_path(r'^upload/common/$', views.CommonView.as_view()),
]
