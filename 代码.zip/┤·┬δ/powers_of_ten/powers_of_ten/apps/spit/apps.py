from django.apps import AppConfig


class SpitConfig(AppConfig):
    name = 'spit'
