from rest_framework import serializers
from .models import Spit


class SpitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Spit
        fields = '__all__'