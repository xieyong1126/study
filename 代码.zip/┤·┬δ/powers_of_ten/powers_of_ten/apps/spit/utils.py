from django_redis import get_redis_connection


def transfer(list, request):
    try:
        redis_conn = get_redis_connection('default')
        collected_set = redis_conn.smembers('collected_%s' % request.user.id)
        collected_list = []
        for item in collected_set:
            collected_list.append(int(item))
        thumbup_set = redis_conn.smembers('thumbup_%s' % request.user.id)
        thumbup_list = []
        for item in thumbup_set:
            thumbup_list.append(int(item))
        for dict in list:
            if dict.get('id') in collected_list:
                dict['collected'] = True
            if dict.get('id') in thumbup_list:
                dict['hasthumbup'] = True
    except Exception as e:
        return None

    return list