from rest_framework import serializers

from headline.models import Article
from person.models import User
from qa.models import Label, Question, Reply

# 标签
class LabelsSerializer(serializers.ModelSerializer):
    # avatar = serializers.CharField()
    class Meta:
        model = Label
        fields = ('label_name', 'id',)

# 用户
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'avatar')

# 答案
class ReplySerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    class Meta:
        model = Reply
        fields = ('id', 'content', 'createtime', 'useful_count', 'unuseful_count', 'user')

# 问题评论
class ReplyCommentSerializer(serializers.ModelSerializer):
    subs = serializers.SerializerMethodField(read_only=True)
    user = UserSerializer(read_only=True)
    class Meta:
        model = Reply
        fields = ('id','content','createtime','useful_count','problem', 'unuseful_count', 'subs', 'user', 'parent')
    def get_subs(self, obj):
        data =obj.subs.all()
        subs = []
        for i in data:
            subs.append(i.content)
        return subs

# 问题答案
class ReplyAnswerSerializer(serializers.ModelSerializer):
    subs = serializers.SerializerMethodField(read_only=True)
    user = UserSerializer()
    class Meta:
        model = Reply
        fields = ('id', 'content', 'createtime', 'useful_count','problem','unuseful_count','subs','user','parent')
    def get_subs(self, obj):
        data = Reply.objects.filter(parent=obj)
        return ReplySerializer(data, many=True).data

#  问题详情
class QuestionsSerializer(serializers.ModelSerializer):
    labels = serializers.SerializerMethodField()
    comment_question = serializers.SerializerMethodField()
    answer_question = serializers.SerializerMethodField()
    user = serializers.CharField()
    class Meta:
        model = Question
        fields = ('id', 'createtime', 'labels', 'reply', 'replyname', 'replytime', 'title',
                  'useful_count', 'unuseful_count', 'user', 'visits', 'content', 'comment_question','answer_question')
    def get_labels(self, obj):
        data = obj.labels.all()
        labels = []
        for i in data:
            labels.append(i.label_name)
        return labels


    def get_comment_question(self, obj):
        comments = obj.replies.filter(type=0)
        return ReplyCommentSerializer(comments, many=True).data
    def get_answer_question(self, obj):
        answers = obj.replies.filter(type=2)
        return ReplyAnswerSerializer(answers, many=True).data

#  发布问题
class QuestionsPostSerializer(serializers.ModelSerializer):
    labels = serializers.SerializerMethodField()
    user = serializers.StringRelatedField()
    class Meta:
        model = Question
        fields = '__all__'
    def get_labels(self, obj):
        data = obj.labels.all()
        labels = []
        for i in data:
            labels.append(i.label_name)
        return labels



#  回答问题
class ReplyQuestionSerializer(serializers.ModelSerializer):
    # problem = serializers.PrimaryKeyRelatedField()
    # parent = serializers.PrimaryKeyRelatedField()
    user_id = serializers.IntegerField()
    class Meta:
        model = Reply
        fields = '__all__'


# 标签详情 ---------------------------------------------------------------------

class ArticleUserArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = ('id', 'title')

class ArticleUserSerializer(serializers.ModelSerializer):
    articles = serializers.SerializerMethodField()
    fans = serializers.SerializerMethodField()
    class Meta:
        model = User
        fields = ('id', 'username', 'avatar', 'articles', 'fans')
    def get_articles(self, obj):
        data = obj.articles.all()
        return ArticleUserArticleSerializer(data, many=True).data
    def get_fans(self, obj):
        data = obj.fans.all()
        fans = []
        for i in data:
            fans.append(i.id)
        return fans

class LabelQuestionSerializer(serializers.ModelSerializer):
    labels = serializers.SerializerMethodField()
    class Meta:
        model = Question
        fields = '__all__'
    def get_labels(self, obj):
        data = obj.labels.all()
        labels = []
        for i in data:
            labels.append(i.label_name)
        return labels

# class UserArticleSerializer(serializers.ModelSerializer):
#     articles = serializers.SerializerMethodField()
#     fans = serializers.SerializerMethodField()
#     class Meta:
#         model = User
#         fields = ('id', 'username', 'avatar', 'articles','fans')
#     def articles(self, obj):


class ArticlesSerializer(serializers.ModelSerializer):
    user = ArticleUserSerializer()
    collected_users = serializers.SerializerMethodField()
    class Meta:
        model = Article
        exclude = ('thumbup', 'updatetime', 'comment_count', 'channel', 'labels')
    def get_user(self, obj):
        data = obj.users.all()
        return ArticleUserSerializer(data, many=True).data
    def get_collected_users(self, obj):
        data = obj.collected_users.all()
        collected_users = []
        for i in data:
            collected_users.append(i.id)
        return collected_users




class LabelsDetailSerializer(serializers.ModelSerializer):
    questions = serializers.SerializerMethodField()
    users = serializers.SerializerMethodField()
    articles = serializers.SerializerMethodField()
    class Meta:
        model = Label
        fields = '__all__'

    def get_questions(self, obj):
        data = obj.questions.all()
        return LabelQuestionSerializer(data, many=True).data

    def get_users(self, obj):
        data = obj.users.all()
        users = []
        for i in data:
            users.append(i.id)
        return users

    def get_articles(self, obj):
        data = obj.articles.all()
        return ArticlesSerializer(data, many=True).data


# labels/full ----------------------------------------------------------------
class LabelFullSerializer(serializers.ModelSerializer):
    users = serializers.SerializerMethodField()
    class Meta:
        model = Label
        fields = '__all__'
    def users(self, obj):
        data = obj.users.all()
        users = []
        for i in data:
            users.append(i.id)
        return users