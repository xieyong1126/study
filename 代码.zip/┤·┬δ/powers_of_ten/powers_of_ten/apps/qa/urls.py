from django.urls import re_path
from rest_framework_jwt.views import obtain_jwt_token

from . import views
from rest_framework.routers import DefaultRouter
urlpatterns = [
    # re_path(r'^authorizations/$', obtain_jwt_token),
]

router = DefaultRouter()
# 全, 单标签的问题
# 关注, 取消关注标签, 标签详情
router.register(r'labels', views.LabelsModelView, basename='labels')
# 新, 热, 待回答的问题
router.register(r'questions/(?P<id>-?\d+)/label', views.QuestionsModelView, basename='questions/')
# 问题发布和详情, 问题有没有用
router.register(r'questions', views.QuestionsMessageModelView, basename='questions')
# 回答问题, 回答有没有用
router.register(r'reply', views.ReplyModelView, basename='reply')
urlpatterns += router.urls
