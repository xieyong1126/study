import datetime

from django.shortcuts import render

# Create your views here.
from django.views import View
from rest_framework.decorators import action
from rest_framework.generics import ListAPIView, RetrieveAPIView

from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from activity.activity_serializers import GatheringSimpleSerialiezer, GatheringDetailSerializer
from activity.models import Gathering
from activity.pages import PageNum




class GatheringSimpleView(ListAPIView):

    # 指定视图所使用的查询集
    queryset = Gathering.objects.all().order_by('id')
    # 指定视图所使用的序列化器类
    serializer_class = GatheringSimpleSerialiezer

    pagination_class = PageNum


class GatheringDetailView(RetrieveAPIView):

    # 指定视图所使用的查询集
    queryset = Gathering.objects.all()
    # 指定视图所使用的序列化器类
    serializer_class = GatheringDetailSerializer



class GatheringJoinView(APIView):



    def post(self, request, pk):
        gathering = Gathering.objects.get(id=pk)
        now_datetime = datetime.datetime.now()
        if now_datetime > gathering.endrolltime:
            return Response({'success': False, 'message': '报名时间已过'})
        user = request.user
        if user in gathering.users.all():
            gathering.users.remove(user)
            return Response({'success': True, 'message': '取消成功'})
        gathering.users.add(user)
        return Response({'success': True, 'message': '参加成功'})



