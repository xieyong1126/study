from django.urls import re_path
from . import views
urlpatterns = [

    # 活动页面显示
    re_path(r'^gatherings/$', views.GatheringSimpleView.as_view()),
    # 活动页面详情
    re_path(r'^gatherings/(?P<pk>\d+)/$', views.GatheringDetailView.as_view()),

    # 活动报名
    re_path(r'^gatherings/(?P<pk>\d+)/join/$', views.GatheringJoinView.as_view()),


]