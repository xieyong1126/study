from rest_framework import serializers

from activity.models import Gathering


class GatheringSimpleSerialiezer(serializers.ModelSerializer):
    '''活动序列化器类'''
    class Meta:
        model = Gathering
        fields = ('id','name','image','city','starttime','endrolltime','users')
        # fields = '__all__'

class GatheringDetailSerializer(serializers.ModelSerializer):
    '''活动序列化器类'''
    class Meta:
        model = Gathering
        fields = '__all__'