import base64
import json
import os
import re
import uuid

from django.http import JsonResponse, response, Http404
from django.shortcuts import render
from django.views import View
from django_redis import get_redis_connection
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.generics import ListAPIView, UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework_jwt.authentication import jwt_decode_handler

from headline.pages import PageNum
from person.models import User
from person.serializers import UserSerializer, LabelsSerializer, LikeSerializer, UpdateLabelSerializer
from powers_of_ten.settings.dev import BASE_DIR
from powers_of_ten.utils.fastdfs.fastdfs_storage import FastDFSStorage
from qa.models import Label


class PersonListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        person = User.objects.filter(id=request.user.id)
        # person = User.objects.all()
        serializer = UserSerializer(person, many=True)
        for i in serializer.data:
            # print(dict(i))
            return JsonResponse(dict(i))

    def put(self, request):
        rcv_data = json.loads(request.body.decode())
        # print(rcv_data)

        src = rcv_data['avatar']
        # if src:
        #     User.objects.filter(id=request.user.id).update(avatar=None)
        #     return JsonResponse({'errmsg': '请重试'})

        # print(src)
        result = re.search("data:image/(?P<ext>.*?);base64,(?P<data>.*)", src, re.DOTALL)
        if result:
            '''判断是否第一次上传，个人档案头像只能上传一次'''
            ext = result.groupdict().get("ext")
            data = result.groupdict().get("data")

            # filepath = '/Users/mac/Desktop/'
            filepath = os.path.dirname(os.path.dirname(os.path.dirname(BASE_DIR)))

            # 2、base64解码
            img = base64.urlsafe_b64decode(data)
            filename = "{}.{}".format(uuid.uuid4(), ext)

            filepath_new = filepath + '/' + filename
            with open(filepath_new, "wb") as f:
                f.write(img)

            print(filepath_new)

            f = open(filepath_new, 'rb')
            ret = FastDFSStorage.save(self, name='name.jpg', content=f, max_length=None)
            url = FastDFSStorage.url(self, ret)

            # print(url)

            person_change = User.objects.filter(id=request.user.id).update(
                realname=rcv_data['realname'],
                sex=rcv_data['sex'],
                birthday=rcv_data['birthday'],
                website=rcv_data['website'],
                mobile=rcv_data['mobile'],
                email=rcv_data['email'],
                city=rcv_data['city'],
                address=rcv_data['address'],
                avatar=url,
            )
        else:
            person_change = User.objects.filter(id=request.user.id).update(
                realname=rcv_data['realname'],
                sex=rcv_data['sex'],
                birthday=rcv_data['birthday'],
                website=rcv_data['website'],
                mobile=rcv_data['mobile'],
                email=rcv_data['email'],
                city=rcv_data['city'],
                address=rcv_data['address'],
                avatar=rcv_data['avatar']
            )

        person = User.objects.filter(id=request.user.id)
        serializer = UserSerializer(person, many=True)
        for i in serializer.data:
            # print(dict(i))
            return JsonResponse(dict(i))


class PasswordView(View):
    '''修改密码'''

    def put(self, request):
        rcv_data = json.loads(request.body.decode())

        new_pwd = rcv_data.get('new_pwd')

        if not new_pwd:
            return JsonResponse({
                'message': '修改失败~',
                'type': 'error'
            })

        try:
            request.user.set_password(new_pwd)
            request.user.save()
        except Exception as e:
            return JsonResponse({'message': '修改失败~',
                                 'type': 'error'})
        return JsonResponse({
            'message': '修改成功',
            'type': 'success'
        })


class LikeView(APIView):
    '''添加好友关注和取消好友关注'''

    def post(self, request, pk):
        user_obj = User.objects.get(id=request.user.id)
        fans_obj = User.objects.get(id=pk)

        user_obj.fans.add(fans_obj)

        return JsonResponse({
            'success': True,
            'message': '关注成功'
        })

    def delete(self, request, pk):
        user_obj = User.objects.get(id=request.user.id)
        fans_obj = User.objects.get(id=pk)

        user_obj.fans.remove(fans_obj)

        return JsonResponse({
            'success': True,
            'message': '取消关注'
        })


class AvatarView(View):
    def post(self, request):
        '''头像上传'''

        rec_data = request.FILES.get('img')

        # FastDFSStorage.exists(data)

        ret = FastDFSStorage.save(self, name='name.jpg', content=rec_data, max_length=None)
        url = FastDFSStorage.url(self, ret)

        return JsonResponse({
            'imgurl': url
        })


class CommonView(View):
    def post(self, request):
        '''前端副文本编辑器上传图片'''
        rec_data = request.FILES.get('upload')

        # FastDFSStorage.exists(data)

        ret = FastDFSStorage.save(self, name='name.jpg', content=rec_data, max_length=None)
        image_url = FastDFSStorage.url(self, ret)
        url = "http://www.1024.site:8080/upload_success.html?image_url=" + image_url + "&CKEditorFuncNum=1"

        # http://127.0.0.1/upload_success.html?image_url=http://47.92.144.35:443/group1/M00/00/00/rBACxl3ggw2AZ1CbAAAo5jLCaQc72
        # 73744&CKEditorFuncNum=1
        return response.HttpResponseRedirect(url);


# 修改擅长技术
class UpdatelabelView(UpdateAPIView):
    serializer_class = UpdateLabelSerializer
    # permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user
