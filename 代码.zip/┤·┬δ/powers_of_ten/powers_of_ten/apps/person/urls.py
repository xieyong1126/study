from django.urls import re_path
from rest_framework.routers import DefaultRouter

from . import views

urlpatterns = [

    re_path(r'^user/$', views.PersonListView.as_view()),
    re_path(r'^user/password/$', views.PasswordView.as_view()),
    re_path(r'^upload/avatar/$', views.AvatarView.as_view()),
    re_path(r'^upload/common/$', views.CommonView.as_view()),
    re_path(r'^users/like/(?P<pk>\d+)/$', views.LikeView.as_view()),
    # re_path(r'^user/label/$', views.UpdatelabelView.as_view()),
]

# router = DefaultRouter()
# router.register(r'users/like', views.LikeView, basename='idols')
#
# urlpatterns += router.urls