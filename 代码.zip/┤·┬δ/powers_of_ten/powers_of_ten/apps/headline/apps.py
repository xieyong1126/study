from django.apps import AppConfig


class HeadlineConfig(AppConfig):
    name = 'headline'
