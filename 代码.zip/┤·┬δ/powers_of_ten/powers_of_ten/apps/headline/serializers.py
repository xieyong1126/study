from rest_framework import serializers
from rest_framework.response import Response

from headline.models import Channel, Article, Comment
from person.models import User
from qa.models import Label


class ChannelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Channel
        fields = ['id','name']

class ArticleSerializerForCreate(serializers.ModelSerializer):
    image = serializers.CharField(required=False, default='',allow_blank=True)

    class Meta:
        model = Article
        exclude = ('collected_users',)

class ArticleSerializerSimple(serializers.ModelSerializer):

    class Meta:
        model = Article
        fields = ("id", "title")

class UserDetailSerializer(serializers.ModelSerializer):

    articles = ArticleSerializerSimple(read_only=True, many=True)

    class Meta:
        model = User
        fields = ('id', 'username','avatar','articles','fans')

class UserSerializer(serializers.ModelSerializer):

    username = serializers.StringRelatedField()# 用户名昵称
    articles = serializers.StringRelatedField(many=True) # 用户发布的文章个人网站

    class Meta:
        model = User
        fields = '__all__'


class CommentSerializerItem(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)
    subs = serializers.PrimaryKeyRelatedField(read_only=True, many=True)

    class Meta:
        model = Comment
        fields = ('id', 'content','article','user','parent','subs','createtime')

class Comment3SerializerList(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)

    class Meta:
        model = Comment
        fields = "__all__"

class Comment2SerializerList(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)
    subs = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = "__all__"
    def get_subs(self, obj):
        subs = Comment.objects.filter(parent=obj)
        return Comment3SerializerList(subs, many=True).data

class CommentSerializerList(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)
    subs = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = "__all__"
    def get_subs(self, obj):
        subs = Comment.objects.filter(parent=obj)
        return Comment2SerializerList(subs, many=True).data

class ArticleSerializerForDetail(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)
    comments = serializers.SerializerMethodField()
    labels = serializers.SerializerMethodField()
    collected_users = serializers.SerializerMethodField()
    class Meta:
        model = Article
        fields = '__all__'
    def get_labels(self, obj):
        data = obj.labels.all()
        # labels = Label.objects.all()
        labels_list = []
        for i in data:
            labels_list.append(i.id)
        return labels_list
    def get_collected_users(self, obj):
        data = obj.collected_users.all()
        # users = User.objects.filter(id=1)
        users_list = []
        for i in data:
            users_list.append(i.username)
        return users_list
    def get_comments(self, obj):
        comments = Comment.objects.filter(article=obj).filter(parent=None)
        return CommentSerializerList(comments, many=True).data


class ArticleSerializerForList(serializers.ModelSerializer):
    user = UserDetailSerializer(read_only=True)
    collected = serializers.BooleanField(default=False)

    class Meta:
        model = Article
        fields = ("id", "title","content","createtime","user","collected_users","collected","image","visits")

class CommentSerializer(serializers.ModelSerializer):
    parent_id = serializers.IntegerField()
    class Meta:
        model = Comment
        fields = ['article','content','parent']

    def create(self, validated_data):
        # 保存数据
        comment = Comment.objects.create(**validated_data)

        return comment



#  发布评论
class ArticleCommentSerialzier(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = '__all__'