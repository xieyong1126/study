from amqp import channel
from django.urls import re_path
from rest_framework.routers import DefaultRouter, SimpleRouter

import headline
from headline.views import ChannelList
from . import views

urlpatterns = [

    re_path(r'^channels/$', views.ChannelList.as_view()),
    re_path(r'^articles/search/$', views.MySearchView.as_view()),

]
router = DefaultRouter()
router.register(r'article', views.ArticleViewSet,basename='article')
# router.register(r'article', views.ArticleListView,basename='id')

urlpatterns += router.urls