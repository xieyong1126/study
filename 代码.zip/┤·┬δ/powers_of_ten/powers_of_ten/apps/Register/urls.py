from django.urls import re_path
from rest_framework_jwt.views import obtain_jwt_token

from . import views

urlpatterns = [
    # 发送短信
    re_path(r'^sms_codes/(?P<mobile>1[3-9]\d{9})/$', views.SmsView.as_view()),

    # 注册
    re_path(r'^users/$', views.CreateUserView.as_view()),

    # 登录
    re_path(r'^authorizations/$', obtain_jwt_token),

]
