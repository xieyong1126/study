``` python
#django环境下

import os,sys
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'jingdong.settings.dev')
sys.path.insert(0,'/home/ubuntu/Desktop/jingdong_project/jingdong')
import django
django.setup()

from django.utils import timezone

local_time = timezone.localtime()
time_str = local_time.strftime('%Y%m%d%H%M%S')

print(time_str)
```

```python
import datetime
#时间字符串转成datetime或date类型
end = '2100-12-3'  #str
new = datetime.datetime.strptime(end, '%Y-%m-%d')#2100-12-03 00:00:00

a = datetime.datetime.now()
#2020-07-06 08:43:02.686942 <class 'datetime.datetime'> 
#datetime.datetime类型和datetime.date类型可以直接比较大小

#datetime或date类型转成时间字符串
#start_date---><class 'datetime.datetime'> 
#end_date----><class 'datetime.date'>
sd_str = datetime.datetime.strftime(start_date,'%Y-%m-%d')
sd_str = datetime.date.strftime(end_date,'%Y-%m-%d')

? start_date_str = start_date.strftime('%Y-%m-%d')
#datetime.datetime型转成datetime.date类型

```

##### 计算

``` python
begin_date = datetime.strptime(begin_date, “%Y-%m-%d”)
end_date = datetime.strptime(end_date, “%Y-%m-%d”)
得到可计算的时间类型
days = ((end_date - begin_date).days)
计算结果需要转化成Integer类型
得到时间差days


```

``` python
import time
from datetime import datetime,timedelta

"""
time:产生时间戳
datetime.datetime:时间转换模块
datetime.timedelta:时间间隔模块
"""
#时间戳
timestamp = time.time()
print('时间戳：',timestamp)

#时间戳转换成日期
date = datetime.fromtimestamp(timestamp)
print(type(date))
print('日期时间',date)

#日期格式转换成字符串
date_str = datetime.isoformat(date)
print('标准日期时间字符串:',date_str)

#日期转成自定义字符串
#date_str1 = datetime.strftime(date,"%Y-%m-%d %H:%M:%S:%f")
date_str1 = datetime.strftime(date,"%Y-%m-%d %H:%M:%S")
print('日期转成自定义字符串:',date_str1)

#日期转成时间戳
timestamp1 = datetime.timestamp(date)
print('日期转成时间戳',timestamp1)

#日期字符串转换成日期
date1 = datetime.strptime(date_str,format='%Y-%m-%d %H:%M:%S')
print('日期字符串转换成日期:',date1)
```

