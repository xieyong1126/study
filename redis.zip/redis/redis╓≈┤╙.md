- 作用
  - 数据备份
  - 读写分离
- 特点
  - 只能一主多从 (mysql可以多主多从)
  - 从数据库不能写入 (mysql可以写)

#### 相关配置

``` base
# 主从数据库分别配置ip/端口 如果不设置, 则接受来自任意IP的请求(包括外网、局域网、本机)
# bind 127.0.0.1
port 6379
# 从数据库配置slaveof参数: 主数据库ip 主数据库端口
slaveof 192.168.105.140 6378

# 以下两条连起来: 当至少有2个从数据库可以进行复制并且响应延迟都在10秒之内时, 主数据库才允许写操作    
min-slaves-to-write 2 
min-slaves-max-lag 10  


# ubuntu的redis安装目录, 其中包含了redis和sentinal的配置模板
/usr/local/redis/

# ubuntu中 启动/重启/停止 默认的redis服务
/etc/init.d/redis-server start/restart/stop
```

``` base
redis-cli -p #请定端口连接
info #查看信息
```

