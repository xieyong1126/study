"""
该模块，用于构建celery程序对象，并加载配置和加载任务函数
"""
import os


from celery import Celery
# 1、新建一个celery应用程序对象
celery_app = Celery("celery_xiexie")

# 2、加载配置信息(指定任务队列)
celery_app.config_from_object('celery_test.config')

# 3、加载任务(celery中，任务是需要被封装成一个包文件的！)
celery_app.autodiscover_tasks([
    'celery_test.task1',
])


#定时任务5秒一次
celery_app.conf.beat_schedule = {
    'add-every-30-seconds': {
        'task': 'sum',  #用任务的名字 name="sum"
        'schedule': 5.0,
        'args': (16, 16)
    },
}

#定时任务 ，每天周一7点半
# from celery.schedules import crontab
# celery_app.conf.beat_schedule = {
#     # Executes every Monday morning at 7:30 a.m.
#     'add-every-monday-morning': {
#         'task': 'sum',
#         'schedule': crontab(hour=7, minute=30, day_of_week=1),
#         'args': (16, 16),
#     },
# }


"""
后台启动
celery multi start w1 -A celery_test.main -l info
重启
celery  multi restart w1 -A celery_test.main -l info
停止
celery multi stop w1 -A celery_test.main -l info
"""

"""
启动定时任务
celery -A celery_test.main beat

"""