from celery_test.main import celery_app

from celery.utils.log import get_task_logger
logger = get_task_logger('celery_log')



@celery_app.task(name="sum")
def add(x,y):
    logger.info("任务执行了")
    return x+y