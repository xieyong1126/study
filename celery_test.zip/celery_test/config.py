"""
需要指定任务队列！！
"""

# 是一个redis缓存的链接
broker_url='redis://127.0.0.1:6379/3'
result_backend='redis://127.0.0.1:6379/4'
task_serializer = 'json'
result_serializer = 'json'
accept_content = ['json']
timezone = 'Asia/Shanghai'
enable_utc = True

# 使用rabbitmq缓存数据库充当任务队列
# broker_url = 'amqp://meihao:123456@172.16.238.128:5672'

"""
broker_url = 'pyamqp://'
result_backend = 'rpc://'

task_serializer = 'json'
result_serializer = 'json'
accept_content = ['json']
timezone = 'Asia/Shanghai'
enable_utc = True

Celery 也可以设置任务执行错误时的专用队列中
task_routes = {
    'tasks.add': 'low-priority',
}

Celery 也可以针对任务进行限速，以下为每分钟内允许执行的10个任务的配置
task_annotations = {
    'tasks.add': {'rate_limit': '10/m'}
}

app.conf.update(
    result_expires=3600,
)
"""

#日志
import logging
from logging import config

LOG_CONFIG = {
	'version': 1,
	'disable_existing_loggers': False,  # 是否禁用已存在的日志器
	'formatters': {
		# 日志信息显示格式
		'simple': {
			'format': '%(asctime)s \"%(module)s:%(funcName)s:%(lineno)d\" [%(levelname)s - %(message)s]',
		},
	},
	'handlers': {
		'celery': {
			# 向文件中输出日志
			'level': 'INFO',
			'class': 'concurrent_log_handler.ConcurrentRotatingFileHandler',
			'maxBytes': 5 * 1024 * 1024,  # 分割大小（5M）
			'backupCount': 10,  # 保存10份
			'filename': 'log.log',  # 日志文件位置
			'formatter': 'simple',
			'encoding': 'utf-8',
		},
	},
	'loggers': {
		# 日志器
		'celery_log': {
			'handlers': ['celery'],
			'propagate': True,  # 是否继续传递日志信息
			'level': 'INFO' # 日志器接收的最低日志级别
		}
	},
}

logging.config.dictConfig(LOG_CONFIG)

"""
from celery.utils.log import get_task_logger
logger = get_task_logger('celery_log')
"""
