``` python
#https://www.cnblogs.com/xiaomifeng0510/p/12072081.html

#centos下载安装谷歌（无界面版本）
#wget https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
#yum install google-chrome-stable_current_x86_64.rpm
#查看版本 google-chrome -version
#下载对应版本的chromedriiver  #http://npm.taobao.org/mirrors/chromedriver
#解压后把chromedriver移动到/usr/bin/目录下 查看版本chromedriver --version

from selenium import webdriver
import time
options = webdriver.ChromeOptions()
options.add_argument("--headless")
options.add_argument("--disable-gpu")
options.add_argument('--no-sandbox')
driver = webdriver.Chrome('chromedriver',chrome_options=options)
driver.get('http://www.itcast.cn')
time.sleep(1)
print(driver.title)
time.sleep(1)
driver.quit()

# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
#
# chrome_options = Options()
# chrome_options.add_argument('--headless')  # 无界面
# chrome_options.add_argument('--no-sandbox')  # 解决DevToolsActivePort文件不存在报错问题
# chrome_options.add_argument('--disable-gpu')  # 禁用GPU硬件加速。如果软件渲染器没有就位，则GPU进程将不会启动。
# chrome_options.add_argument('--disable-dev-shm-usage')
# chrome_options.add_argument('--window-size=1920,1080')  # 设置当前窗口的宽度和高度
# driver = webdriver.Chrome('chromedriver', chrome_options=chrome_options)
#
# driver.get("https://www.cnblogs.com/yoyoketang/")
# print(driver.page_source)
#
# # driver.get('http://www.itcast.cn')
# #
# # print(driver.title)
# driver.quit()
```

