Django权限总览：

- 消费者用户与公司内部运营用户使用**一个用户模型类**来存储
- 通过**is_staff 来区分**是运营用户还是消费者用户
- 对于运营用户通过**is_superuser 来区分**是运营平台的管理员还是运营平台的普通用户
- 对于权限，Django会为每个数据库表提供**增、删、改、查四种权限**
- 用户最终的权限为 **组权限 + 用户特有权限**



##### 1、通过用户对象判断该用户是否有某权限

```python
user = User.objects.get(pk=4)

# 单一权限校验
# has_perm('<模型类所属app_label>.<add_模型类名小写>') # 插入权限
user.has_perm('orders.add_orderinfo') # 插入OrderInfo的权限
# has_perm('<模型类所属app_label>.<add_模型类名小写>') # 修改权限
user.has_perm('orders.change_orderinfo') # 修改OrderInfo的权限
# has_perm('<模型类所属app_label>.<add_模型类名小写>') # 删除权限
user.has_perm('orders.delete_orderinfo') # 删除OrderInfo的权限

# 多个权限校验
# has_perms(['<模型类所属app_label>.<add_模型类名小写>', '<模型类所属app_label>.<change_模型类名小写>', <模型类所属app_label>.<delete_模型类名小写>])
```

##### 2、自定义权限验证类

```python
from rest_framework.permissions import BasePermission

# 自定义权限类
class ModifyOrderInfo(BasePermission):
    def has_permission(self, request, view):
        # 判断用户是否有操作OrderInfo的权限
        user = request.user
        if user.is_anonymous:
            return False
        return user.has_perms(['orders.add_orderinfo', 'orders.change_orderinfo', 'orders.delete_orderinfo'])

 # 模型类中通过类属性permission_classes指定自定义的权限验证
 class OrderAPIView(UpdateModelMixin, ReadOnlyModelViewSet):

    queryset = OrderInfo.objects.all()
    serializer_class = OrderSimpleSerializer

    pagination_class = MyPage

    permission_classes = [
        IsAdminUser,
        # 自定义权限验证，必须拥有对OrderInfo增删改的权限才能够访问
        ModifyOrderInfo
    ]
```

