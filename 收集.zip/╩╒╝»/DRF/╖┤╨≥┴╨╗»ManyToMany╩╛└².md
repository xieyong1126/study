##### 示例代码

``` python
from rest_framework import serializers
from users.models import User


class AdminModelSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'email',
            'mobile',

            'password',
            'groups',
            'user_permissions'
        ]
        extra_kwargs = {
            'password':{'write_only':True}
        }
	
    #重写create方法，原方法在下面，
    #为什么要重写create方法，因为原方法没有create_superuser，create_user方法
    #为什么要先pop出ManyToMany，因为要先创主表对象，然后再创从表数据
    def create(self, validated_data):
        
        #1  把中间表字段去除
        groups = validated_data.pop('groups')
        user_permissions = validated_data.pop('user_permissions')
        #2 新建主表
        user = User.objects.create_superuser(**validated_data)
        #3 通过ManyToMany字段的set方法设置中间表数据
        user.groups.set(groups)
        user.user_permissions.set(user_permissions)

        return user
```

``` python
#serializer.ModelSerializer自带的create方法

# Default `create` and `update` behavior...
def create(self, validated_data):
 
    raise_errors_on_nested_writes('create', self, validated_data)

    ModelClass = self.Meta.model

    # Remove many-to-many relationships from validated_data.
    # They are not valid arguments to the default `.create()` method,
    # as they require that the instance has already been saved.
    info = model_meta.get_field_info(ModelClass)
    many_to_many = {}
    for field_name, relation_info in info.relations.items():
        if relation_info.to_many and (field_name in validated_data):
            many_to_many[field_name] = validated_data.pop(field_name)

    try:
        instance = ModelClass._default_manager.create(**validated_data)
    except TypeError:
        tb = traceback.format_exc()
        msg = (
            'Got a `TypeError` when calling `%s.%s.create()`. '
            'This may be because you have a writable field on the '
            'serializer class that is not a valid argument to '
            '`%s.%s.create()`. You may need to make the field '
            'read-only, or override the %s.create() method to handle '
            'this correctly.\nOriginal exception was:\n %s' %
            (
                ModelClass.__name__,
                ModelClass._default_manager.name,
                ModelClass.__name__,
                ModelClass._default_manager.name,
                self.__class__.__name__,
                tb
            )
        )
        raise TypeError(msg)

    # Save many-to-many relationships after the instance is created.
    if many_to_many:
        for field_name, value in many_to_many.items():
            field = getattr(instance, field_name)
            field.set(value)

    return instance
```