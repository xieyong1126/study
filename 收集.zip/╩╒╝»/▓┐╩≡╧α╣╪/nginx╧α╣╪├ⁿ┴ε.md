``` 
安装：apt install nginx -y(-y，自动选y)
检查效果：netstat -tnulp | grep nginx#查看当前系统下的端口和IP使用情况，浏览器查看 
服务相关命令：
systemctl start nginx
systemctl stop nginx
systemctl reload nginx

sudo /etc/init.d/nginx start
sudo /etc/init.d/nginx stop
sudo /etc/init.d/nginx restart














```

