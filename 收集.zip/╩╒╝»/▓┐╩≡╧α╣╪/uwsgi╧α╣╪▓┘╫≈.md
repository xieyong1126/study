#### **.准备生产环境启动文件** 内层工作目录.wsgi.py

``` python
import os

from django.core.wsgi import get_wsgi_application

# 指定上线使用的配置文件
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'meiduo_mall.settings.prod')

# Django框架应用本尊
application = get_wsgi_application()
```

##### 安装uwsgi包

` pip instanll uwsgi`

##### 准备uwsgi服务配置文件

``` 
新建meiduo_mall.uwsgi.ini配置文件

[uwsgi]
# 使用Nginx连接时使用，Django程序所在服务器地址
socket=192.168.208.129:8001
# 直接做web服务器使用，Django程序所在服务器地址
#http=127.0.0.1:8000
# 项目目录
# chdir=项目路径/mei_project/mei_mall(外层工作目录)
chdir=/home/ubuntu/data/meiduo_mall
# 项目中wsgi.py文件的目录，相对于项目目录
wsgi-file=meiduo_mall/wsgi.py
# 进程数
processes=4
# 线程数
threads=2
# uwsgi服务器的角色
master=True
# 存放进程编号的文件
pidfile=uwsgi.pid
# 日志文件
daemonize=uwsgi.log
# 指定依赖的虚拟环境  whereis python3
# virtualenv=/Users/meihao/.virtualenvs/project
virtualenv=/home/ubuntu/.virtualenvs/untitled1
```

**启动**` $ uwsgi --ini uwsgi.ini`  （在uwsgi.ini同级目录下）

**关闭**  ` $ uwsgi --stop uwsgi.pid`

**查看** ` ps aux | grep uwsgi`

###  部署Nginx服务器反向代理

在 `/etc/nginx/conf.d/ `目录下，新建配置文件 8000.conf

``` 
#反向代理多台服务器
upstream www.meiduo.site {#自定义名
	server 192.168.203.161:8001;#服务器的IP和port
	server 192.168.203.161:8002;
}
	server {
	listen 8000;#监听端口
	location / {
	include uwsgi_params;
	uwsgi_pass www.meiduo.site;
	}
}
```

##### 重启nginx服务

` sudo /etc/init.d/nginx [start|stop|restart] `

` systemctl [start|stop|reload] nginx `

