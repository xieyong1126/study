#### 1. 安装uwsgi

```
进入虚拟环境

pip install uwsgi
或者
pip install uwsgi -i https://pypi.tuna.tsinghua.edu.cn/simple/Looking in indexes: https://pypi.tuna.tsinghua.edu.cn/simple/
```

#### 2. 准备生产环境配置文件

```
2.1 复制开发环境配置文件dev.py的内容到生产环境配置文件prod.py中

2.2 取消调试模式如下：
	# DEBUG = True
	DEBUG = False
```

#### 3. 准备生产环境启动文件

```
3.1 生产环境我们是使用jingdong.wsgi.py启动Django程序的

3.2 修改wsgi.py文件如下
	os.environ.setdefault("DJANGO_SETTINGS_MODULE", "jingdong.settings.prod")
```

#### 4. 准备uwsgi服务器配置文件

```
4.1 jingdong.uwsgi.ini配置文件
```

```python
[uwsgi]
# 使用Nginx连接时使用，Django程序所在服务器地址
# socket=127.0.0.1:8001
# 直接做web服务器使用，Django程序所在服务器地址
http=192.168.31.29:8001
# 项目目录
# chdir=工程根目录
chdir=外层工程目录的绝对路径
# 项目中wsgi.py文件的目录，相对于项目目录
wsgi-file=jingdong/wsgi.py
# 进程数
processes=4
# 线程数
threads=2
# uwsgi服务器的角色
master=True
# 存放进程编号的文件
pidfile=uwsgi.pid
# 日志文件
daemonize=uwsgi.log
# 指定依赖的虚拟环境
# virtualenv=虚拟环境路径
virtualenv=/Users/zhangjie/.virtualenvs/django_base_2.2
```

#### 5. 管理uwsgi服务器

```bash
5.1 启动
	uwsgi --ini uwsgi.ini
5.2 关闭
	uwsgi --stop uwsgi.pid
5.3 强杀
	sudo kill -9 pid
```

#### 6. 测试

```
访问商品列表数据
http://192.168.21.21:8001/list/115/skus/?page=1&page_size=5&ordering=-create_time
```

