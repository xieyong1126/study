往 session 中存储或者读取数据使用的对象都是 request
存储时调用的格式是: ```request.session['key'] = 'value'```
获取 session 中的数据格式是: ```value = request.session['key']```
删除使用的格式: del request.session['key']
设置有效期使用的格式: ```request.session.set_expiry( value )```

清除所有 session，在存储中删除值部分:```request.session.clear()```

清除 session 数据，在存储中删除 session 的整条数据:``` request.session.flush()```

