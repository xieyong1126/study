``` python
import os,sys
#'jingdong.settings.dev'配置文件
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'jingdong.settings.dev')

#添加导包路径
sys.path.insert(0,'/home/ubuntu/Desktop/jingdong_project/jingdong')
import django
django.setup()
```

