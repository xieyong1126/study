在ubuntu中已经运行了一个占用3306端口的mysql，作为**主服务器**；

我们使用Docker来新建一个mysql**从服务器**！



### 一、准备阶段

#### 1、在ubuntu宿主机中新建一个用于映射从服务器的工作目录（该目录中用于记录从服务器的数据和配置文件）

```python
# 1、进入家目录
cd ~
# 2、在家目录中新建文件夹
mkdir mysql_slave
```

#### 2、把主mysql配置文件拷贝一份到`mysql_slave文件夹中`，作为从服务器的配置文件

```python
sudo cp -r /etc/mysql/mysql.conf.d ~/mysql_slave
sudo mkdir ~/mysql_slave/data
```

### 二、恢复用于构建mysql从服务器的Docker镜像

#### 1、把`mysql_docker_5722.tar`压缩包拷贝到你的ubuntu中；

#### 2、使用上述第1步的压缩包恢复镜像

```python
sudo docker image load --input mysql_docker_5722.tar
```

### 三、使用上述的恢复的镜像，运行起一个具备mysql从服务的容器

#### 1、修改从mysql服务器配置文件

```python
# 1、打开事先准备的从服务器配置文件
vim ~/mysql_slave/mysql.conf.d/mysqld.cnf

# 2、修改成如下配置项
# 从机端口号
# port = 8306
# 关闭日志
# general_log = 0
# 从机唯一编号
# server-id = 2
```

##### 2、使用docker把mysql从服务器(容器)运行起来

```python
sudo docker container run  -itd  --name mysql-slave  --network=host -v /home/python/mysql_slave/mysql.conf.d/:/etc/mysql/mysql.conf.d/  -v /home/python/mysql_slave/data/:/var/lib/mysql/  -e MYSQL_ROOT_PASSWORD=123456 mysql:5.7.22
```

### 四、修改主服务器配置文件

如果主服务器配置文件有所修改，则需要重启主mysql服务器；

```python
vim /etc/mysql/mysql.conf.d/mysqld.cnf

# 修改如下配置
# 开启日志: 把下面的代码注释去掉
# general_log_file = /var/log/mysql/mysql.log
# general_log = 1
# 主机唯一编号
# server-id = 1
# 二进制日志文件
# log_bin = /var/log/mysql/mysql-bin.log
```

### 五、把主服务器原有的数据“手动”恢复到从服务器中

##### 1、导入主服务器数据

```python
# 1. 收集主机原有数据
mysqldump -uroot -pmysql --all-databases --lock-all-tables > ~/master_db.sql
```

#### 2、把数据导入从服务器

```python
# 2. 从机复制主机原有数据
mysql -uroot -p123456 -h127.0.0.1 --port=8306 < ~/master_db.sql
```

### 六、配置主从同步账户

```python
# 在主服务器中配置一个给从服务器只用的，用于同步数据使用的账号
# 1、登陆mysql主服务器
mysql -uroot -pmysql
# 2、在mysql主服务器交互环境下执行如下sql
mysql> grant all privileges on *.* to 'slave'@'%' identified by 'slave';
mysql> flush privileges;
```

### 七、查看主服务器同步的二进制文件信息

在主服务器交换环境(客户端)中执行命令` SHOW MASTER STATUS;`查看如下：

![image-20200703101633723](../Library/Application Support/typora-user-images/image-20200703101633723.png)

记住，文件名(msyql-bin.000100)和文件位置(1167)

### 八、在从服务器中指定主服务器

```python
mysql> change master to master_host='192.168.203.161', master_user='slave', master_password='slave',master_log_file='mysql-bin.000100', master_log_pos=1167;
mysql> start slave;
```

### 九、查看从服务器状态

```python
mysql> show slave status \G;
```

![image-20200703102235306](../Library/Application Support/typora-user-images/image-20200703102235306.png)

红色位置都为“Yes”说明配置成功！

