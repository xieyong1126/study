##### 1、在django配置文件`dev.py`中新增mysql从服务器的配置项

```python
# 修改django配置文件如下新增一个“slave”数据库配置项指向从mysql服务器
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'meiduo_mall_db',
        'HOST': '192.168.203.161',
        'USER': 'root',
        'PASSWORD': 'mysql',
        'PORT': 3306
    },
    'slave': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'meiduo_mall_db',
        'HOST': '192.168.203.161',
        'USER': 'root',
        'PASSWORD': '123456',
        'PORT': 8306
    }
}
```

##### 2、自定义Django数据库路由后端

Django数据库路由：用来指定，Django读写数据库的所使用的具体配置；

- 新建`meiduo_mall/utils/db_router.py`文件

- 在该文件中新建数据库路由后端

  ```python
  """
  自定义Django数据库路由后端
  """
  
  class MasterSlaveDBRouter(object):
  
      # 重写里面的一些方法来指定：写到"default"，从"slave"中读
  
      def db_for_read(self, *args, **kwargs):
          # 从slave配置指向的从mysql读
          return "slave"
  
  
      def db_for_write(self, *args, **kwargs):
          # 写入default配置指向的主mysql
          return "default"
  
      def allow_relation(self, obj1, obj2, **hints):
          # 允许关联操作
          return True
  ```

- 在配置文件`dev.py`中指定路由

  ```python
  # 指定自定义的数据库路由后端导包路径
  DATABASE_ROUTERS = [
      'meiduo_mall.utils.db_router.MasterSlaveDBRouter'
  ]
  ```



