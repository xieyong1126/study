##### 1、安装uwsgi服务器

`pip3 install uwsgi`

##### 2、修改Django线上部署配置文件

把`dev.py`开发配置文件内容，拷贝到`prod.py`中；把`prod.py`里面的一些可能的配置项改为真正上线使用的参数！

##### 3、修改`meiduo_mall/wsgi.py`文件

![image-20200703150512963](../Library/Application Support/typora-user-images/image-20200703150512963.png)

##### 4、启动`uwsgi`服务器 —— 调用Django框架，构建完整的web动态服务器

- 准备`uwsgi`配置文件——新建`meiduo_mall/uwsgi.ini`配置文件,内容修改如下（uwsgi.ini配置文件要在django工程外层目录下新建）

  ```text
  [uwsgi]
  # 使用Nginx连接时使用，Django程序所在服务器地址
  # socket=127.0.0.1:8001
  # 直接做web服务器使用，Django程序所在服务器地址
  http=127.0.0.1:8000
  # 项目目录
  # chdir=项目路径/meiduo_project/meiduo_mall
  chdir=/Users/weiwei/Desktop/sz37_meiduo_mall/meiduo_mall
  # 项目中wsgi.py文件的目录，相对于项目目录
  wsgi-file=meiduo_mall/wsgi.py
  # 进程数
  processes=4
  # 线程数
  threads=2
  # uwsgi服务器的角色
  master=True
  # 存放进程编号的文件
  pidfile=uwsgi.pid
  # 日志文件
  daemonize=uwsgi.log
  # 指定依赖的虚拟环境
  # virtualenv=/Users/meihao/.virtualenvs/project
  virtualenv=/Users/weiwei/.virtualenvs/django_env
  ```

- 基于配置文件运行动态服务器（uwsgi服务器+django框架）

  ```python
  python@ubuntu$ uwsgi --ini uwsgi.ini # 启动
  python@ubuntu$ uwsgi --stop uwsgi.pid # 关闭
  sudo kill -9 pid 强杀
  ```

  