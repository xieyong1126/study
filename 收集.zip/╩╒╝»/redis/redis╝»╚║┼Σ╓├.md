### 主从配置

```python
# 在/etc/redis中创建二个配置文件

# 6380.conf
port 6380

# 6381.conf
port 6381
slaveof 127.0.0.1 6380


# 分别启动主从数据库
sudo redis-server 6380.conf
sudo redis-server 6381.conf

# 进入客户端使用 info命令查看
```



### 配置哨兵步骤

```python
# 在/etc/redis中创建三个配置文件

# sentinel_26380.conf
port 26380  
sentinel monitor mymaster 127.0.0.1 6381 2  
sentinel down-after-milliseconds mymaster 30000  
daemonize yes 
logfile "/var/log/redis-sentinel-26380.log"
  
# sentinel_26381.conf
port 26381  
sentinel monitor mymaster 127.0.0.1 6381 2  
sentinel down-after-milliseconds mymaster 30000  
daemonize yes 
logfile "/var/log/redis-sentinel-26381.log"

# sentinel_26382.conf
port 26382
sentinel monitor mymaster 127.0.0.1 6381 2  
sentinel down-after-milliseconds mymaster 30000  
daemonize yes 
logfile "/var/log/redis-sentinel-26382.log"


# 执行命令
sudo redis-sentinel sentinel_26380.conf
sudor redis-sentinel sentinel_26381.conf
sudo redis-sentinel sentinel_26382.conf

```



# redis六个集群配置信息

```python
# 新建：/etc/redis/7000.conf
port 7000
bind 0.0.0.0
daemonize yes
pidfile 7000.pid
cluster-enabled yes
cluster-config-file 7000_node.conf
cluster-node-timeout 15000
appendonly yes



# 新建：/etc/redis/7001.conf
port 7001
bind 0.0.0.0
daemonize yes
pidfile 7001.pid
cluster-enabled yes
cluster-config-file 7001_node.conf
cluster-node-timeout 15000
appendonly yes


# 新建：/etc/redis/7002.conf
port 7002
bind 0.0.0.0
daemonize yes
pidfile 7002.pid
cluster-enabled yes
cluster-config-file 7002_node.conf
cluster-node-timeout 15000
appendonly yes


# 新建：/etc/redis/7003.conf
port 7003
bind 0.0.0.0
daemonize yes
pidfile 7003.pid
cluster-enabled yes
cluster-config-file 7003_node.conf
cluster-node-timeout 15000
appendonly yes


# 新建：/etc/redis/7004.conf
port 7004
bind 0.0.0.0
daemonize yes
pidfile 7004.pid
cluster-enabled yes
cluster-config-file 7004_node.conf
cluster-node-timeout 15000
appendonly yes


# 新建：/etc/redis/7005.conf
port 7005
bind 0.0.0.0
daemonize yes
pidfile 7005.pid
cluster-enabled yes
cluster-config-file 7005_node.conf
cluster-node-timeout 15000
appendonly yes
```

# 启动每一个redis数据库

```python

sudo /usr/local/bin/redis-server /etc/redis/7000.conf &
sudo /usr/local/bin/redis-server /etc/redis/7001.conf &
sudo /usr/local/bin/redis-server /etc/redis/7002.conf &
sudo /usr/local/bin/redis-server /etc/redis/7003.conf &
sudo /usr/local/bin/redis-server /etc/redis/7004.conf &
sudo /usr/local/bin/redis-server /etc/redis/7005.conf &
```

# 启动集群

```bash
# 第一步
cd ~/redis-4.0.13/src/

# 第二步
redis-trib.rb create --replicas 1 0.0.0.0:7000 0.0.0.0:7001 0.0.0.0:7002 0.0.0.0:7003  0.0.0.0:7004  0.0.0.0:7005
```







