### 重点提醒：提交（add）前git status  查看是否修改了他人文件。避免冲突

（一）： 还没有add

git checkout 文件名   ---------将文件修改的操作从工作区撤回



（二）：已经执行了add ，git status 发现不小心修改了他人文件，想回退，执行下面两步 


git reset HEAD 文件名  -----------将指定文件从暂存区撤回到工作区（HEAD指当前版本）

git checkout 文件名   ---------将文件修改的操作从工作区撤回



  (三 )已经commit  了

git commit -am ''    快速合并 add commit 操作

git reset --hard  HEAD^       一个^，回退一个版本

git reset --hard + '版本编号'   （危险，慎用）回退工作区，暂存区，

git reset --soft + '版本编号'    不会回退工作区和暂存区

git reset --mixed + '版本编号'    不会回退工作区  （危险程度最低）

例如： git reset --mixed  HEAD^

git reflog 查看版本号，以及版本切换记录



 （四）如果发现别人代码问题，导致自己无法测试代码，千万别试图修改他人代码。一个原因是工作的时候不背锅；二个是代码牵一发动全身，搞不好整个工程都乱套了。

  

#   查看ssh公钥

cd  ~/.ssh/   家目录下的ssh文件

more id_rsa.pub  查看公钥



git branch  查看当前分支

git checkout -b XX  新建分支

git push --set-upstream origin XX  分支提交代码