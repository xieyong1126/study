**升级**

``` bash
pip install -U pip        #liunx
python -m pip install -U pip  #windows
```



**生成requirements**

``` 
pip freeze > requirements.txt
pip install -r requirements.txt
```

**安装离线 **

``` 
pip install SomePackage-1.0-py2.py3-none-any.whl
```

**安装wheel**

```
pip install wheel
```

**下载离线包**

``` 
pip wheel --wheel-dir=文件夹 -r requirements.txt
pip wheel --wheel-dir=文件夹 安装包名
```

**安装离线包**

``` 
pip install --no-index --find-links=文件夹 -r requirements.txt
pip install --no-index --find-links=文件夹 安装包名
```

