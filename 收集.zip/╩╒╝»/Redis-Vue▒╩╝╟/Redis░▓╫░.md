# Redis安装

下载

```
wget http://download.redis.io/releases/redis-4.0.9.tar.gz
```

解压

```
tar xzf redis-4.0.9.tar.gz
```

移动，放到usr/local目录下

```
sudo mv ./redis-4.0.9 /usr/local/redis/
```

进入redis目录

```
cd /usr/local/redis/
```

生成

```
sudo make
```

测试

```
sudo make test
```

安装,将redis的命令安装到`/usr/local/bin/`目录

```
sudo make install
```

安装完成后，我们进入目录`/usr/local/bin`中查看

```
cd /usr/local/bin
ls -all
-----------------
redis-server redis服务器
redis-cli redis命令行客户端
redis-benchmark redis性能测试工具
redis-check-aof AOF文件修复工具
redis-check-rdb RDB文件检索工具
```

配置文件，移动到`/etc/`目录下

配置文件目录为`/usr/local/redis/redis.conf`

```
sudo cp /usr/local/redis/redis.conf /etc/redis/
```

## 其他补充

- Mac 上安装 Redis:

  - 安装 Homebrew：

  > https://brew.sh/

  - 使用 brew 安装 Redis

  > https://www.cnblogs.com/cloudshadow/p/mac_brew_install_redis.html