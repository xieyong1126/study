``` 
/etc/init.d/redisd start
/etc/init.d/redisd stop

sudo redis-server /etc/redis/redis.conf
```

