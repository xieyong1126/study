# Vue的基本使用

- 使用步骤
  - 编写HTML
  - 准备<div>
  - 导入Vue.js
  - 创建Vue对象，绑定页面，声明变量
  - 变量渲染HTML

- 基本语法
  - 绑定属性：v-bind   简写 " : "
  - 事件监听：v-on   简写 " @ "
  - 条件与循环：v-if、v-for
  - 双向绑定：v-model
  - 控制标签是否展示：v-show

```html
<script src="vue.js"></script>

<body>
   <!-- 定义盒子容器 -->
    <div id="app">
        <span>{{ username }}</span>
        <span>{{ password }}</span>
    </div>
    
    
    <!-- 创建Vue对象，绑定页面，声明变量 -->
    <script>
    	var vm = new Vue({
            // 绑定页面
            el:'#app',
            data:{
                usernaem:"115"
                password:"123456"
            },
            // 声明和实现方法
            methods:{
                
            }
            
        });
    
    </script>
</body>
```

