# Vue的基本语法

- #### 绑定属性：v-bind

  ```html
  <body>
      <div id="#app">
      	<img v-bind:src="image">
      </div>
      
      <script>
      	var vm = new Vue({
              el:"#app",
              data:{
                  image:"www.baidu.com"
              }
          })
      </script>
  </body>
  ```

- #### 事件监听器v-on

  ```html
  <body>
      <div id="#app">
          <button v-on:click="btnClick">点我</button>
      </div>
      
      <script>
      	var vm = new Vue({
              el:"#app",
              methods:{
                  btnClick:function(){
                      alert("被点击")
                  }
              }
          })
      </script>
  </body>
  ```

- #### 条件与循环v-if、v-for

  ```html
  <!-- 条件 -->
  <body>
      <div id="#app">
          <div v-if="seen">true</div>
          <div v-else>false</div>
      </div>
      
      <script>
      	var vm = new Vue({
              el:"#app",
              data:{
                  seen:true,
              }
          })
      </script>
  </body>
  ```

  ```html
  <!-- 循环 -->
  <body>
      <div di="#app">
          <ul>
              <li v-for:"i in subjects">{{ i }}</li>
          </ul>
      </div>
      
      <script>
      	var vm = new Vue({
              el:"#app",
              data:{
                  subjects:[
                      "第一个",
                      "第二个",
                      "第三个"
                  ]
              }
          })
      </script>
  </body>
  ```

- #### 双向绑定v-model

  ```html
  <body>
      <div id="#app">
          <input v-model="username" type="text" placeholder="请输入...">
          <div>您输入的是：{{ username }}</div>
      </div>
      
      <script>
      	var vm = new Vue({
              el:"#app",
              data:{
                  username:"",
              }
          });
      </script>
  </body>
  ```

- #### 是否展示v-show

```html
<body>
	<div id="#app">
        <input v-model="username" v-on:blur="check_name"type="text" placeholder="请输入...">
        <span v-show="username_error">用户名位数不够</span>
    </div>
    
    <script>
    	var vm = new Vue({
            el:"#app",
            data:{
                username:"",
                username_error=false,
            },
            methods:{
                check_name:function(){
                    if(!this.username.length>5){
                        this.username_error = false
                    }else{
                        this.username_error = true
                    }
                }
            }
        })
    </script>
</body>
```

- ### 案例展示

```html
<body>
	<div id="app">
		<h2>To do list</h2>
		<input v-model='content' type="text" id="txt1" class="inputtxt">
		<input @click='fnAdd'type="button" id="btn1" class="inputbtn" value="增加">
		
		<ul id="list" class="list">
			<li v-for='(sub,index) in data_list'>
				<span>{{sub}}</span>
				<a @click='fnUP(index)' href="javascript:;" class="up"> ↑ </a>
				<a @click='fnDown(index)' href="javascript:;" class="down"> ↓ </a>
				<a @click='fnDel(index)' href="javascript:;" class="del">删除</a>
			</li>
		</ul>
	</div>

	<script>
		var vm = new Vue({
			el:'#app',
			data:{
				content:'',
				data_list:['学习html','学习css','学习javascript'],
				
			},
			methods:{
				// 添加
				fnAdd:function(){
					// 判断是否有内容
					if (!this.content){
						alert("内容不能为空")
						return
					}
					// 如果有内容，将内容添加到data_list
					this.data_list.push(this.content)
					// 清空输入框
					this.content = ''
				},
				// 上
				fnUP:function(index){
					oldData = this.data_list[index]
					this.data_list.splice(index,1)
					if(index==0){
						this.data_list.push(oldData)
					}else{
						this.data_list.splice(index-1,0,oldData)
					}
					
				},
				// 下
				fnDown:function(index){
					// 根据下标获取对应的数据
					oldData = this.data_list[index]
					// 删除对应位置的数据
					this.data_list.splice(index, 1)
					// 在下一个位置 插入
					if(index<this.data_list.length-1){
						this.data_list.splice(index +1, 0, oldData)
					}else{
						this.data_list.splice(0,0,oldData)
					}
					
				},
				// 删除
				fnDel:function(index){
					//删除(下标,删除个数)
					this.data_list.splice(index,1)
				},
			}
		})
	</script>
</body>

</html>

```

