
uwsgi --ini /data/jingdong_mall/uwsgi.ini
nginx -g "daemon off;"

