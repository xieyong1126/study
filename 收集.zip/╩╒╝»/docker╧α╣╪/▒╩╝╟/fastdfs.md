##### 上传文件的方法有两种, 分别为:

``` python
# 这个是通过文件名上传文件
client.upload_by_filename(上传文件的绝对路径)

# 或是通过这个方法: 
# 这个是通过文件内容上传文件:
client.upload_by_buffer(上传文件的bytes数据)

#删除文件
client.delete_file(file_id)
#返回值0成功，2文件不存在，其它出错
```

##### 在 dev.py 文件中, 导入 fastDFS_client 所需要的设置:

``` 
# FDFS需要的配置文件路径(即: client.conf文件绝对路径). 
FDFS_CLIENT_CONF = os.path.join(BASE_DIR, 'utils/fastdfs/client.conf')
# FDFS中storage和tracker位置.端口规定死是8888, ip换成自己的ip
# 电脑ip为172.16.238.128
FDFS_URL = 'http://172.16.238.128:8888/'
# 指定django系统使用的文件存储类:
DEFAULT_FILE_STORAGE = 'me_mall.utils.fastdfs.fastdfs_storage.FastDFSStorage'




```

##### 添加访问图片的域名:

- 在 `/etc/hosts` 中添加访问 Storage 的域名

```python
# Storage 的 IP    域名
172.16.238.128    image.medu.site
```

``` python
def create(self, request, *args, **kwargs):
          # 创建FastDFS连接对象
        client = Fdfs_client(settings.FASTDFS_PATH)
        # 获取前端传递的image文件
        data = request.FILES.get('image')
        # 上传图片到fastDFS
        res = client.upload_by_buffer(data.read())
        # 判断是否上传成功
        if res['Status'] != 'Upload successed.':
            return Response(status=403)
        # 获取上传后的路径
        image_url = res['Remote file_id']
        # 获取sku_id
        sku_id = request.data.get('sku')[0]
        # 保存图片
        img = SKUImage.objects.create(sku_id=sku_id, image=image_url)
                # 返回结果
        return Response(
            {
                'id': img.id,
                'sku': sku_id,
                'image': img.image.url
            },
            status=201  # 前端需要接受201状态
        )
```

``` python
from apps.utils.fastdfs.fastdfs_storage import FastDFSStorage

#富文本图片上传
class UploadImage(View):
    '''上传图片,,富文本编辑器'''
    def post(self,request):

        # client = Fdfs_client('powers_of_ten/apps/utils/fastdfs/client.conf')
        data = request.FILES.get('upload')
        #
        # res = client.upload_by_buffer(data.read())
        # if res['Status'] != 'Upload successed.':
        #     return
        #     # 获取上传后的路径
        # image_url = res['Remote file_id']
        # image_url = settings.FDFS_URL + image_url
        
        #方法2，直接调用
        o = FastDFSStorage()
        image_url =settings.FDFS_URL+ o.save(name=None,content=data)
        print(image_url)

        url = 'http://127.0.0.1:8080/upload_success.html?image_url=' + image_url + "&CKEditorFuncNum=1"
        print(url)
        #return redirect(url)
        return HttpResponseRedirect(url)
```

