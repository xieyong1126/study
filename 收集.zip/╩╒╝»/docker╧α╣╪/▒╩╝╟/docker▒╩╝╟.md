##### 概念

docker是一个用于快速环境部署工具；就是把我们需要的各种服务提前安装好，并且构建成一个镜像，之后直接把该镜像运行起来成容器，这个容器中就具备了我们安装好的各项服务！

##### 1、镜像

```shell
# 基本操作
docker search [image_name]	# 搜索	
docker pull [image_name]		# 获取	
docker images <image_name>	# 查看 	
docker history [image_name]	# 历史	

# 进阶操作
docker tag [old_image]:[old_version] [new_image]:[new_version] # 标签
docker rmi [image_id/image_name:image_version] # 删除	
docker save -o [包文件] [镜像] # 导出	
docker load < [image.tar_name] # 导入	
```

##### 2、容器

```shell
# 基本操作
docker ps -a # 查看	
docker run -itd <image_name> # 新建并启动	
docker start [container_id] # 启动	 
docker stop [container_id] # 关闭 	
docker rm [-f] [container_id] # 删除	

# 进阶操作
docker exec -it [container_id] /bin/bash # 
# -i:则让容器的标准输入保持打开。
# -t:让docker分配一个伪终端,并绑定到容器的标准输入上
# /bin/bash:执行一个命令，就是我们的交互终端程序
docker commit -m '改动信息' -a "作者信息" [container_id [new_image:tag] # # 提交，当我们对容器的环境做了修改之后需要把该容器提交成一个镜像
docker logs [container_id] # 日志	
docker inspect [container_id] # 属性	
```

##### 3、数据管理

```shell
# 容器目录映射
docker run -itd --name [容器名字] -v [宿主机文件]:[容器文件] [镜像名称]

# 新建数据卷容器
docker create -v [容器数据卷目录] --name [容器名字] [镜像名称] [命令(可选)]
# 在新建容器的时候根据数据卷容器进行目录映射
docker run --volumes-from [数据卷容器id/name] -tid --name [容器名字] [镜像名称]
```

##### 4、网络管理

```shell
# 随机端口映射,随机宿主机端口从32768递增
docker run -itd -P nginx:latest
# 指定端口映射
docker run -itd -p <宿主机ip>:<宿主机端口>:<容器端口> nginx:latest

# host模式:意味容器直接使用宿主机网络进行通信；启动的时候确保，容器中开放的端口，在宿主机中是否已经被占用；
docker run -itd --network=host nginx:latest
```

ss