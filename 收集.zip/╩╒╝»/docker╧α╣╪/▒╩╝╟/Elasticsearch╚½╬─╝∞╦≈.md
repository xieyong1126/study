### 使用 Docker 安装 Elasticsearch

```bash
# 从仓库拉取镜像
sudo docker image pull delron/elasticsearch-ik:2.4.6-1.0
```

```bash
# 或者是: 解压本地镜像
sudo docker load -i elasticsearch-ik-2.4.6_docker.tar
将资料中的elasticsearc-2.4.6目录拷贝到home目录下。
修改/home/elasticsearc-2.4.6/config/elasticsearch.yml第54行。
更改 ip 地址为本机真实 ip 地址。
(network.host:192.168.208.129)
```

**使用 Docker 运行 Elasticsearch-ik**

` sudo docker run -dti --name=elasticsearch --network=host -v /home/elasticsearch-2.4.6/config:/usr/elasticsearch/config delron/elasticsearch-ik:2.4.6-1.0`

### Haystack 介绍和安装配置

```bash
联网安装haystack和elasticsearch
pip install django-haystack
pip install elasticsearch==2.4.1
```

**Haystack 注册应用**

```python
INSTALLED_APPS = [
     # 全文检索
    'haystack', 
]
```

**Haystack 配置**

在配置文件中配置 Haystack 为搜索引擎后端

```python
# Haystack
HAYSTACK_CONNECTIONS = {
    'default': {
        'ENGINE': 'haystack.backends.elasticsearch_backend.ElasticsearchSearchEngine',
        'URL': 'http://192.168.208.129:9200/', # Elasticsearch服务器ip地址，端口号固定为9200
        'INDEX_NAME': 'jingdong', # Elasticsearch建立的索引库的名称
    },
}

# 当添加、修改、删除数据时，自动生成索引
HAYSTACK_SIGNAL_PROCESSOR = 'haystack.signals.RealtimeSignalProcessor'
#HAYSTACK_SIGNAL_PROCESSOR 配置项保证了在 Django 运行起来后，有新的数据产生时，Haystack 仍然可以让 Elasticsearch 实时生成新数据的索引
```

 **Haystack 建立数据索引**

- 通过创建索引类，来指明让搜索引擎对哪些字段建立索引，也就是可以通过哪些字段的关键字来检索数据。
- 本项目中对 SKU 信息进行全文检索，所以在 `goods` 应用中新建 `search_indexes.py` 文件，用于存放索引类。

```python
from haystack import indexes
from .models import SKU
class SKUIndex(indexes.SearchIndex, indexes.Indexable):
    """SKU索引数据模型类"""
    text = indexes.CharField(document=True, use_template=True)
    def get_model(self):
        """返回建立索引的模型类"""
        return SKU
    def index_queryset(self, using=None):
        """返回要建立索引的数据查询集"""
        return self.get_model().objects.filter(is_launched=True)
    #is_launched=True未下架，是过虑条件
#其中 text 字段我们声明为 document=True，表名该字段是主要进行关键字查询的字段。
#text字段的索引值可以由多个数据库模型类字段组成，具体由哪些模型类字段组成，我们用 use_template=True 表示后续通过模板来指明。
```

**.创建 text 字段索引值模板文件**

` 在 `templates` 目录中创建 `text 字段`使用的模板文件,具体在 templates/search/indexes/goods/sku_text.txt 文件中定义（goods=应用名，sku_text=模型类小写名_text）`

```python
{{ object.id }}
{{ object.name }}
{{ object.caption }}
#id,name,caption作为text字段的索引值，（是模型中的字段）
```

**手动生成初始索引**

` python manage.py rebuild_index`

### 全文检索测试

> **1.准备测试表单**

- 请求方法：`GET`
- 请求地址：`/search/`
- 请求参数：`q`

### 添加后端逻辑

> 在 goods.views.py 文件中添加如下代码:
>
> ```python
> # 导入: 
> from haystack.views import SearchView
> 
> class MySearchView(SearchView):
>     '''重写SearchView类'''
>     def create_response(self):
>         page = self.request.GET.get('page')
>         # 获取搜索结果
>         context = self.get_context()
>         data_list = []
>         for sku in context['page'].object_list:
>             data_list.append({
>                 'id':sku.object.id,
>                 'name':sku.object.name,
>                 'price':sku.object.price,
>                 'default_image_url':sku.object.default_image_url,
>                 'searchkey':context.get('query'),
>                 'page_size':context['page'].paginator.num_pages,
>                 'count':context['page'].paginator.count
>             })
>         # 拼接参数, 返回
>         return JsonResponse(data_list, safe=False)
> ```

**在 goods.urls.py 中添加子路由:**

` re_path(r'^search/$', views.MySearchView()),`











































