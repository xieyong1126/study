**1.视图**

`pip install flask-restful`

**构建RESTAPI**

``` python
from flask import Flask
from flask_restful import Api, Resource, output_json
import json

# json.dumps(ensure_ascii=False)

# 创建Flask应用对象
app = Flask(__name__)

# Flask原生框架配置
app.config["JSON_AS_ASCII"] = False
# Flask-restful中文编码问题
app.config["RESTFUL_JSON"] = {"ensure_ascii": False}

# 1.将app对象包装成遵循RESTFUL风格的api对象
# 参数： 可以是app对象也可以是蓝图对象
api = Api(app)

# 2.自定义视图类
# 注意：继承Resource
class DemoResource(Resource):

    def get(self):
        # 1.字典会自动被转换成json字符串,并且已经在响应头中设置了content-type:application/json
        return {"foo": "get 你好呀"}

    def post(self):
        return {"foo": "post body"}

# 3.通过api对象给视图类添加路由信息
api.add_resource(DemoResource, '/')

# endpoint="demo" 视图类的别名
# api.add_resource(DemoResource, '/', endpoint="demo")

if __name__ == '__main__':
    print(app.url_map)
    app.run(debug=True)
```

**类视图设置装饰器**

```
通过 method_decorators类属性 来设置类视图的装饰器
该属性接收两种类型数据
列表形式: 所有请求方式都会使用列表中的装饰器
字典形式: 给请求方式分别设置装饰器
```

``` python
from flask import Flask
from flask_restful import Api, Resource

app = Flask(__name__)

# 创建api组间对象
api = Api(app)

def mydecorator1(f):
    def wrapper(*args, **kwargs):
        print("mydecorator1 dispatch")
        return f(*args, **kwargs)
    return wrapper

def mydecorator2(f):
    def wrapper(*args, **kwargs):
        print("mydecorator2 dispatch")
        return f(*args, **kwargs)
    return wrapper


# 需求：如何给类视图中每一个方法添加装饰器
# 自定义类视图
class DemoResource(Resource):
    # 方法1： 给类视图中所有方法同时添加多个装饰器
    # 注意：加载顺序是从左往右,执行顺序是从右往左
    # method_decorators = [mydecorator1, mydecorator2]

    # 方法2：给指定方法添加装饰器
    method_decorators = {
        "get": [mydecorator1, mydecorator2],
        "post": [mydecorator1]
    }

    def get(self):
        return {"foo": "get message"}

    def post(self):
        return {"foo": "post body"}

# 给类视图绑定路由信息
api.add_resource(DemoResource, '/')

if __name__ == '__main__':
    app.run(debug=True)

```

**蓝图和类视图**

```
蓝图和类视图可以配合使用, 步骤如下
1.创建蓝图对象:蓝图对象 = Blueprint('蓝图名', __name__)
2.每个蓝图分别创建组件对象:组件对象 = Api(蓝图对象)
3.组件对象添加类视图:组件对象.add_resource(视图类, URL资源段)
4.应用注册蓝图:应用对象.register_blueprint(蓝图对象)
```

``` python

```

`在 `user`包中创建 `views`文件, 定义类视图`

``` python
# user/views.py
from flask_restful import Resource

class DemoResource(Resource):
    def get(self):
        return {'get': 'hello'}

    def post(self):
        return {'post': 'world'}
```

`在 `user`包 的初始化文件 `__init__.py` 中`

``` python
#创建蓝图对象
#通过蓝图对象创建对应的组件对象
#组件对象添加类视图

# user/__init__.py

from flask import Blueprint
from flask_restful import Api
from user.views import DemoResource

# 1.创建蓝图对象
user_blu = Blueprint('user', __name__, url_prefix='/user')

# 2.创建蓝图对应的api对象
user_api = Api(user_blu)

# 3.添加类视图
user_api.add_resource(DemoResource, '/')
```

`想要让蓝图对象能够完成路由定义, 还需要 **Flask应用注册蓝图对象**`

``` python
# main.py

from flask import Flask
from user import user_blu

app = Flask(__name__)
# 4.注册蓝图
app.register_blueprint(user_blu)


if __name__ == '__main__':
    print(app.url_map)
    app.run(debug=True, port=8000)
```

**2.请求**

`1. 请求解析`

``` 
RequestParser 负责请求解析工作, 基本步骤如下:
1.创建请求解析器:请求解析器 = RequestParser()
2.添加参数规则:请求解析器.add_argument(参数名, 参数规则..)
3.执行解析:参数对象 = 请求解析器.parse_args()
4.获取参数:参数对象.参数名
```

``` python
from flask import Flask
from flask_restful import Api, Resource
from flask_restful.reqparse import RequestParser
# restful参数内置类型
from flask_restful.inputs import *
import re

app = Flask(__name__)

# 1.将app对象包装创建api对象 [用于管理类视图(资源)]
api = Api(app)


def get_user_id(value):
    # user:666
    if re.match(r'^user:', value):
        return value[5:]
    else:
        raise ValueError("格式不正确")


# 2.定义类视图  继承Resource
class DemoResource(Resource):

    def get(self):
        # 需求：参数解析  1.查询字符串 2.form表单 3.请求体json

        # 1.创建解析器对象
        parser = RequestParser()

        # 2.添加需要解析的参数以及解析规则
        # required=True 必须要传
        # location='json' 指定前端传递的参数的方式
        # default=18 默认值
        # parser.add_argument("name", required=True, location='json')
        # parser.add_argument("age", default=18)

        # type python中自带的类型
        parser.add_argument("name", type=str)
        # int_range 限定数据范围
        # parser.add_argument("age", type=int_range(18, 110))

        # regex 正则表达式
        # parser.add_argument("age", type=regex(r'^1[3-9]\d{9}$'))

        # <class 'datetime.datetime'>
        # 将时间字符串转换成datetime时间类型
        # parser.add_argument("age", type=date)

        # boolean布尔类型 True/False 0/1
        # parser.add_argument("age", type=boolean)

        # 自定义类型--函数名作为类型
        parser.add_argument("age", type=get_user_id)

        # 3.开始解析，获取解析结果
        ret = parser.parse_args()

        # 4.从解析结果中提取字段
        print(ret.name)
        print(ret["age"])
        print(type(ret.age))

        return {'foo': 'get'}

    def post(self):
        return {'foo': 'post'}

# 3.api对象给类视图添加路由
api.add_resource(DemoResource, '/')

if __name__ == '__main__':
    print(app.url_map)
    app.run(debug=True)

```

`2. 常用参数`

| 参数     | 说明                                                   | 取值                                         |
| -------- | ------------------------------------------------------ | -------------------------------------------- |
| default  | 给参数设置默认值, 如果不传递该参数会使用默认值         | str/int等                                    |
| required | 是否必须传递,默认False,如果设置为True, 不传递会返回400 | True / False                                 |
| location | 设置参数提取的位置                                     | 字符串, args/form/json/files/headers/cookies |
| type     | 设置参数的转换类型(类型转换 & 格式校验)                | 函数引用, int/内置类型/自定义函数            |

**序列化**

``flask-restful` 通过 `marshal`函数 来完成序列化处理 `

`操作步骤如下 `

```
定义序列化规则:序列化规则 = {字段名: 序列化类型}
marshal函数 按照序列化规则 将模型对象转为字典:序列化后的字典 = marshal(模型对象, 序列化规则)
```

`序列化还有一种装饰器形式 `marshal_with`, 使用装饰器形式则视图可以直接返回模型对象`

`实际开发中, 考虑到序列化的复杂性, 部分公司还会采用 **自定义方法** 的方式来完成序列化处理`

- 常用序列化类型:

| 序列化类型 | 说明                                        |
| ---------- | ------------------------------------------- |
| String     | 可转换 字符串类型属性                       |
| Integer    | 可转换 整数类型属性                         |
| Float      | 可转换 浮点数类型属性                       |
| List       | 可转换 列表类型属性, 要求列表中元素类型唯一 |
| Nested     | 可转换 字典类型属性                         |

``` python
from flask import Flask
from flask_restful import Api, Resource, marshal, fields, marshal_with, output_json

app = Flask(__name__)

# 定义模型类
class User:
    def __init__(self):
        self.name = 'zs'
        self.age = 20
        self.height = 1.8
        self.scores = [80, 90]
        self.info = {
            'gender': True
        }

    # 自定义序列化字典
    def to_dict(self):
        my_dict = {
            "name": self.name,
            "age": self.age
        }

        return my_dict


# 序列化规则字典
fields_dict = {
    "name": fields.String(),
    "age": fields.Integer(default=18),
    "height": fields.Float(),
    # 字段类型为列表，列表中所有的元素类型需要保持一致
    "scores": fields.List(fields.Integer()),#括号里面的括号可加可不加
    # Nested 嵌套的字典类型
    "info": fields.Nested({"gender": fields.Boolean}),

}

# 1.将app对象包装创建api对象 [用于管理类视图(资源)]
api = Api(app)


# 2.定义类视图  继承Resource
class DemoResource(Resource):
    # 方法2：模型对象序列化成json字符串
    # 装饰器value必须是一个列表
    method_decorators = {"post": [marshal_with(fields_dict)]}

    def get(self):
        # 类视图响应的content-type默认变为json形式
        # 类视图的返回值可以是字典, 会被自动转为json字符串
        user = User()

        # 方法1：
        # 将模型对象转序列化json字符串
        # envelope='data' json字符串嵌套，包装
        return marshal(user, fields_dict, envelope='data')

    def post(self):
        # 创建模型对象
        user = User()
        # 返回的模型对象，会经过marshal_with的装饰器，内部实现了模型对象到json字符串的序列化
        return user

    def put(self):
        # 方法3：自定义方法序列化
        user = User()
        return user.to_dict()


# 3.api对象给类视图添加路由
api.add_resource(DemoResource, '/')

if __name__ == '__main__':
    print(app.url_map)
    app.run(debug=True)

```

**自定义JSON**

`实际开发中, 返回的JSON数据中除了包含基础数据, 往往还需要设置一些 **统一的外层包装**, 以便前端进行更好的解析处理`

``flask-restful` 提供了 `api.representation()`装饰器方法, 允许开发者自定义返回的数据格式`

`在实现自定义JSON格式时, 可以参考 `flask-restful` 默认转换函数 (字典转json数据) 的源代码`

`from flask_restful import output_json`

``` python
import json

from flask import Flask
from flask_restful import Api, Resource

app = Flask(__name__)

# 1.将app对象包装创建api对象 [用于管理类视图(资源)]
api = Api(app)

"""
需求：
{
    "name": "zs",
    "age": 20
}

自定义返回json格式：
{
    "message": "OK",
    "data": {
             "name": "zs",
             "age": 20
    }
}

解决方案：

方案1：修改output_json底层源码（不建议）

方案2：复制output_json底层源码，然后使用representation装饰器拦截响应，处理序列化（推荐）

"""

from flask import make_response, current_app
from flask_restful.utils import PY3
from json import dumps


# 方法1：
# representation装饰器作用：拦截返回的字典，调用被装饰的output_json函数进行序列化
# mediatype="application/json" 返回的json响应头中Content-Type为指定的json格式
# @api.representation(mediatype="application/json")
def output_json(data, code, headers=None):
    """Makes a Flask response with a JSON encoded body"""

    # 读取RESTFUL_JSON配置字典
    settings = current_app.config.get('RESTFUL_JSON', {})

    # 如果开起来debug模式
    if current_app.debug:
        # 添加4缩进
        settings.setdefault('indent', 4)
        # 字典key进行排序
        settings.setdefault('sort_keys', not PY3)

    # 不允许中文编码成ASCII
    settings["ensure_ascii"] = False

    # 自定义json格式，添加json外层包装
    if 'message' not in data:  # 判断是否设置了自定义的错误信息
        data = {
            'message': 'ok',
            'data1': data
        }

    # **setting 字典中的配置信息解包
    dumped = dumps(data, **settings) + "\n"
    # 包装成响应对象
    resp = make_response(dumped, code)
    # 添加响应头
    resp.headers.extend(headers or {})
    # 返回响应
    return resp


# 方法2
# 视图函数的主动寻求装饰
# 装饰器名称(参数)(被装饰的视图函数名称)
api.representation(mediatype="application/json")(output_json)


# 2.定义类视图  继承Resource
class DemoResource(Resource):

    def get(self):
        # 类视图响应的content-type默认变为json形式
        # 类视图的返回值可以是字典, 会被自动转为json字符串
        my_dict = {
            "name": "zs",
            "age": 20
        }

        return my_dict

    def post(self):
        return {'foo': 'post'}


# 3.api对象给类视图添加路由
api.add_resource(DemoResource, '/')

if __name__ == '__main__':
    print(app.url_map)
    app.run(debug=True)

```

