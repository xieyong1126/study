##### **导出db1中的a1、a2表,生成脚本**

``` 
mysqldump -uroot -proot --databases db1 --tables a1 a2 >/tmp/db1.sql
```

#### 导入数据 

``` 
mysql  -h127.0.0.1  -uroot  -pmysql  ihome table <  ihome.sql
没有tabley就不填
```

