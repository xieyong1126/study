#!/bin/bash
mysql  -h127.0.0.1  -uroot  -pmysql  ihome <  tb_area.sql
mysql  -h127.0.0.1  -uroot  -pmysql  ihome <  tb_facility.sql
mysql  -h127.0.0.1  -uroot  -pmysql  ihome <  ihome.sql