#### 建立一对一短连接

``` python
#servser
import asyncio
import websockets

async def hello(websocket,path):
    print('------------hello start-------------')
    name = await websocket.recv()
    print(name)
    data = 'hello %s'%name
    await websocket.send(data)
    print(data)

start_server = websockets.serve(hello,host='127.0.0.1',port=8888)

loop = asyncio.get_event_loop()
loop.run_until_complete(start_server)
loop.run_forever()

#client
import asyncio
import websockets

async def hello():
    async with websockets.connect('ws://127.0.0.1:8888') as websocket:
        name = input('your name:')
        await websocket.send(name)
        print(name)

        data = await websocket.recv()
        print(data)

asyncio.get_event_loop().run_until_complete(hello())
```

#### 建立一对一长连接

``` python
#server
import asyncio
import websockets
async def producer_handler(websocket, path):
    print('---- 建立了连接 -----')
    while True:
        message = input('please input:')
        await websocket.send(message)

start_server = websockets.serve(producer_handler, '127.0.0.1', 8080)

asyncio.get_event_loop().run_until_complete(start_server)

asyncio.get_event_loop().run_forever()

#client
import asyncio
import websockets
async def consumer_handler():
    async with websockets.connect(
            'ws://127.0.0.1:8080') as websocket:
        async for message in websocket:
            print(message)
asyncio.get_event_loop().run_until_complete(consumer_handler())
```

#### 建立一对多长连接

``` python
#server
import asyncio
import logging
import websockets

logging.basicConfig()

USERS = set()


async def notify_users():
    # 对注册列表内的客户端进行推送
    if USERS:  # asyncio.wait doesn't accept an empty list
        message = input('please input:')
        await asyncio.wait([user.send(message) for user in USERS])


async def register(websocket):
    USERS.add(websocket)
    await notify_users()


async def unregister(websocket):
    USERS.remove(websocket)
    await notify_users()


async def counter(websocket, path):
    # register(websocket) sends user_event() to websocket
    await register(websocket)
    try:
        # 处理客户端数据请求 （业务逻辑）
        async for message in websocket:
            print(message)
    except Exception:
        pass
    finally:
        await unregister(websocket)

asyncio.get_event_loop().run_until_complete(
    websockets.serve(counter, '127.0.0.1', 8001))
asyncio.get_event_loop().run_forever()

#client
import asyncio
import websockets

async def consumer_handler():
    async with websockets.connect('ws://127.0.0.1:8001') as websocket:
        async for message in websocket:
            print(message)

asyncio.get_event_loop().run_until_complete(consumer_handler())

#client1
import asyncio
import websockets

async def consumer_handler():
    async with websockets.connect('ws://127.0.0.1:8001') as websocket:
        async for message in websocket:
            print(message)

asyncio.get_event_loop().run_until_complete(consumer_handler())
```

